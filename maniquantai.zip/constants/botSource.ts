
export const BOT_SOURCE_CODE = `"""
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║                    MANIQUANTCRYPTO BOT v1.0                               ║
║                 Advanced ML/DL Crypto Trading System                      ║
║                                                                           ║
║  Author: AI Trading Systems                                               ║
║  Platform: MetaTrader 5                                                   ║
║  Python: 3.10+                                                            ║
║                                                                           ║
║  ⚠️  RISK WARNING ⚠️                                                      ║
║  Cryptocurrency trading involves substantial risk of loss.                ║
║  Only trade with capital you can afford to lose.                          ║
║  This software is for educational purposes.                               ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝

INSTALLATION:
pip install MetaTrader5 pandas numpy scikit-learn xgboost tensorflow matplotlib

USAGE:
1. Start MetaTrader 5 and login
2. Run: python maniquant_crypto_bot.py
3. Enter credentials and capital allocation
4. Monitor dashboard and trades

"""

import MetaTrader5 as mt5
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import time
import warnings
from typing import Dict, List, Tuple, Optional
import sys

# ML/DL Libraries
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping

# Visualization
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

warnings.filterwarnings('ignore')


# ═══════════════════════════════════════════════════════════════════════════
#                           MT5 MANAGER CLASS
# ═══════════════════════════════════════════════════════════════════════════

class MT5Manager:
    """
    Manages all MetaTrader 5 interactions including connection, data fetching,
    and trade execution.
    """
    
    def __init__(self):
        self.connected = False
        self.account_info = None
        self.login = None
        self.password = None
        self.server = None
        self.allocated_capital = 0
        self.allocation_percentage = 0
        self.initial_balance = 0
        
    def initialize_connection(self) -> bool:
        """Initialize MT5 connection with user credentials."""
        print("\\n" + "="*80)
        print("MT5 CONNECTION SETUP".center(80))
        print("="*80)
        
        # Get user credentials
        print("\\nPlease enter your MT5 credentials:")
        self.login = input("  MT5 Login ID: ").strip()
        self.password = input("  MT5 Password: ").strip()
        self.server = input("  MT5 Server Name (e.g., Broker-Demo): ").strip()
        
        # Initialize MT5
        print("\\n→ Initializing MT5 connection...")
        if not mt5.initialize():
            error = mt5.last_error()
            print(f"✗ MT5 initialization failed: {error}")
            print("  → Ensure MT5 terminal is running")
            return False
        
        # Login to account
        print("→ Logging in to account...")
        authorized = mt5.login(
            login=int(self.login),
            password=self.password,
            server=self.server
        )
        
        if not authorized:
            error = mt5.last_error()
            print(f"✗ Login failed: {error}")
            print("  → Check credentials and server name")
            mt5.shutdown()
            return False
        
        self.connected = True
        self.account_info = mt5.account_info()
        
        if self.account_info is None:
            print("✗ Failed to retrieve account info")
            return False
        
        self.initial_balance = self.account_info.balance
        
        print(f"\\n✓ Successfully connected to MT5")
        print(f"  Account: {self.account_info.login}")
        print(f"  Server: {self.account_info.server}")
        print(f"  Balance: \${self.account_info.balance:,.2f}")
        print(f"  Equity: \${self.account_info.equity:,.2f}")
        print(f"  Leverage: 1:{self.account_info.leverage}")
        
        return True
    
    def get_capital_allocation(self) -> bool:
        """Prompt user for capital allocation percentage."""
        print("\\n" + "="*80)
        print("CAPITAL ALLOCATION".center(80))
        print("="*80)
        
        print(f"\\nYour current balance: \${self.account_info.balance:,.2f}")
        print("\\nHow much capital would you like to allocate for crypto trading?")
        print("Recommendation: 10-20% for beginners, 20-30% for experienced traders")
        
        while True:
            try:
                pct = float(input("\\nEnter percentage (1-100): "))
                
                if 1 <= pct <= 100:
                    self.allocation_percentage = pct / 100
                    self.allocated_capital = self.account_info.balance * self.allocation_percentage
                    
                    print(f"\\n✓ Allocation confirmed:")
                    print(f"  Total Balance:     \${self.account_info.balance:,.2f}")
                    print(f"  Allocated ({pct}%):  \${self.allocated_capital:,.2f}")
                    print(f"  Reserved:          \${self.account_info.balance - self.allocated_capital:,.2f}")
                    return True
                else:
                    print("⚠ Please enter a value between 1 and 100")
            except ValueError:
                print("⚠ Invalid input. Please enter a number.")
            except KeyboardInterrupt:
                print("\\n✗ Setup cancelled by user")
                return False
    
    def get_historical_data(self, symbol: str, timeframe: int, bars: int = 1000) -> Optional[pd.DataFrame]:
        """Fetch historical OHLCV data from MT5."""
        try:
            # Check symbol availability
            symbol_info = mt5.symbol_info(symbol)
            if symbol_info is None:
                print(f"✗ Symbol {symbol} not found")
                return None
            
            # Enable symbol
            if not symbol_info.visible:
                if not mt5.symbol_select(symbol, True):
                    print(f"✗ Failed to select {symbol}")
                    return None
            
            # Fetch data
            rates = mt5.copy_rates_from_pos(symbol, timeframe, 0, bars)
            
            if rates is None or len(rates) == 0:
                print(f"✗ No data received for {symbol}")
                return None
            
            # Convert to DataFrame
            df = pd.DataFrame(rates)
            df['time'] = pd.to_datetime(df['time'], unit='s')
            
            return df
            
        except Exception as e:
            print(f"✗ Error fetching data: {e}")
            return None
    
    def get_symbol_info(self, symbol: str) -> Optional[Dict]:
        """Get symbol trading specifications."""
        info = mt5.symbol_info(symbol)
        if info is None:
            return None
        
        return {
            'point': info.point,
            'digits': info.digits,
            'spread': info.spread,
            'volume_min': info.volume_min,
            'volume_max': info.volume_max,
            'volume_step': info.volume_step,
            'contract_size': info.trade_contract_size
        }
    
    def calculate_lot_size(self, symbol: str, risk_amount: float, stop_loss_points: float) -> float:
        """Calculate position size based on risk and stop loss."""
        info = self.get_symbol_info(symbol)
        if info is None:
            return info['volume_min']
        
        # Calculate lot size
        point_value = info['point']
        contract_size = info['contract_size']
        
        if stop_loss_points <= 0:
            return info['volume_min']
        
        lot_size = risk_amount / (stop_loss_points * point_value * contract_size)
        
        # Round to volume step
        lot_size = round(lot_size / info['volume_step']) * info['volume_step']
        
        # Clamp to limits
        lot_size = max(info['volume_min'], min(lot_size, info['volume_max']))
        
        return lot_size
    
    def check_margin_available(self, symbol: str, lot_size: float, order_type: int) -> bool:
        """Verify sufficient margin for trade."""
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            return False
        
        price = tick.ask if order_type == mt5.ORDER_TYPE_BUY else tick.bid
        
        result = mt5.order_check(mt5.OrderSendRequest(
            action=mt5.TRADE_ACTION_DEAL,
            symbol=symbol,
            volume=lot_size,
            type=order_type,
            price=price,
        ))
        
        return result is not None and result.margin_free > 0
    
    def execute_trade(self, symbol: str, order_type: int, lot_size: float,
                     sl: float, tp: float, comment: str = "Bot Trade") -> Optional[Dict]:
        """Execute trade on MT5."""
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            print(f"✗ Failed to get tick for {symbol}")
            return None
        
        price = tick.ask if order_type == mt5.ORDER_TYPE_BUY else tick.bid
        
        # Verify margin
        if not self.check_margin_available(symbol, lot_size, order_type):
            print(f"✗ Insufficient margin for {lot_size} lots")
            return None
        
        # Prepare request
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": lot_size,
            "type": order_type,
            "price": price,
            "sl": sl,
            "tp": tp,
            "deviation": 20,
            "magic": 234000,
            "comment": comment,
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        
        # Send order
        result = mt5.order_send(request)
        
        if result is None:
            error = mt5.last_error()
            print(f"✗ Order failed: {error}")
            return None
        
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            print(f"✗ Order rejected: retcode={result.retcode}")
            return None
        
        return {
            'ticket': result.order,
            'volume': result.volume,
            'price': result.price,
            'sl': sl,
            'tp': tp,
            'type': 'BUY' if order_type == mt5.ORDER_TYPE_BUY else 'SELL',
            'time': datetime.now()
        }
    
    def get_open_positions(self, symbol: str = None) -> List[Dict]:
        """Get all open positions."""
        positions = mt5.positions_get(symbol=symbol) if symbol else mt5.positions_get()
        
        if positions is None or len(positions) == 0:
            return []
        
        return [
            {
                'ticket': pos.ticket,
                'symbol': pos.symbol,
                'type': 'BUY' if pos.type == 0 else 'SELL',
                'volume': pos.volume,
                'price_open': pos.price_open,
                'price_current': pos.price_current,
                'sl': pos.sl,
                'tp': pos.tp,
                'profit': pos.profit,
                'swap': pos.swap,
                'time': datetime.fromtimestamp(pos.time)
            }
            for pos in positions
        ]
    
    def close_position(self, ticket: int) -> bool:
        """Close specific position."""
        positions = mt5.positions_get(ticket=ticket)
        if not positions:
            return False
        
        pos = positions[0]
        close_type = mt5.ORDER_TYPE_SELL if pos.type == 0 else mt5.ORDER_TYPE_BUY
        tick = mt5.symbol_info_tick(pos.symbol)
        price = tick.bid if pos.type == 0 else tick.ask
        
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": pos.symbol,
            "volume": pos.volume,
            "type": close_type,
            "position": ticket,
            "price": price,
            "deviation": 20,
            "magic": 234000,
            "comment": "Bot close",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        
        result = mt5.order_send(request)
        return result is not None and result.retcode == mt5.TRADE_RETCODE_DONE
    
    def shutdown(self):
        """Close MT5 connection."""
        if self.connected:
            mt5.shutdown()
            self.connected = False


# ═══════════════════════════════════════════════════════════════════════════
#                        MACHINE LEARNING MODEL CLASS
# ═══════════════════════════════════════════════════════════════════════════

class MLModel:
    """
    Machine Learning classifier using Random Forest and XGBoost ensemble
    for trend prediction.
    """
    
    def __init__(self):
        self.rf_model = None
        self.xgb_model = None
        self.scaler = StandardScaler()
        self.feature_names = []
        self.trained = False
        
    def engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create technical indicators."""
        df = df.copy()
        
        # RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs))
        
        # MACD
        exp1 = df['close'].ewm(span=12, adjust=False).mean()
        exp2 = df['close'].ewm(span=26, adjust=False).mean()
        df['macd'] = exp1 - exp2
        df['macd_signal'] = df['macd'].ewm(span=9, adjust=False).mean()
        df['macd_hist'] = df['macd'] - df['macd_signal']
        
        # Bollinger Bands
        df['bb_middle'] = df['close'].rolling(window=20).mean()
        bb_std = df['close'].rolling(window=20).std()
        df['bb_upper'] = df['bb_middle'] + (bb_std * 2)
        df['bb_lower'] = df['bb_middle'] - (bb_std * 2)
        df['bb_width'] = (df['bb_upper'] - df['bb_lower']) / df['bb_middle']
        df['bb_position'] = (df['close'] - df['bb_lower']) / (df['bb_upper'] - df['bb_lower'])
        
        # Moving Averages
        df['sma_20'] = df['close'].rolling(window=20).mean()
        df['sma_50'] = df['close'].rolling(window=50).mean()
        df['ema_12'] = df['close'].ewm(span=12, adjust=False).mean()
        
        # Momentum
        df['momentum'] = df['close'].pct_change(periods=10)
        df['roc'] = ((df['close'] - df['close'].shift(12)) / df['close'].shift(12)) * 100
        
        # Volume
        df['volume_sma'] = df['tick_volume'].rolling(window=20).mean()
        df['volume_ratio'] = df['tick_volume'] / df['volume_sma']
        
        # ATR
        high_low = df['high'] - df['low']
        high_close = np.abs(df['high'] - df['close'].shift())
        low_close = np.abs(df['low'] - df['close'].shift())
        ranges = pd.concat([high_low, high_close, low_close], axis=1)
        true_range = np.max(ranges, axis=1)
        df['atr'] = true_range.rolling(14).mean()
        
        # Target
        df['target'] = (df['close'].shift(-1) > df['close']).astype(int)
        
        return df.dropna()
    
    def train(self, df: pd.DataFrame):
        """Train ML models."""
        
        df = self.engineer_features(df)
        
        self.feature_names = [
            'rsi', 'macd', 'macd_hist', 'bb_width', 'bb_position',
            'momentum', 'roc', 'volume_ratio', 'atr'
        ]
        
        X = df[self.feature_names].values
        y = df['target'].values
        
        if len(X) < 50:
             raise ValueError("Insufficient data points after feature engineering")

        # Train/test split
        split = int(len(X) * 0.8)
        X_train, X_test = X[:split], X[split:-1]
        y_train, y_test = y[:split], y[split:-1]
        
        # Scale
        X_train = self.scaler.fit_transform(X_train)
        X_test = self.scaler.transform(X_test)
        
        # Train Random Forest
        self.rf_model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42,
            n_jobs=-1
        )
        self.rf_model.fit(X_train, y_train)
        rf_acc = self.rf_model.score(X_test, y_test)
        
        # Train XGBoost
        self.xgb_model = xgb.XGBClassifier(
            n_estimators=100,
            max_depth=6,
            learning_rate=0.1,
            random_state=42,
            eval_metric='logloss'
        )
        self.xgb_model.fit(X_train, y_train)
        xgb_acc = self.xgb_model.score(X_test, y_test)
        
        self.trained = True
        print(f"    ✓ Random Forest accuracy: {rf_acc*100:.2f}%")
        print(f"    ✓ XGBoost accuracy: {xgb_acc*100:.2f}%")
    
    def predict(self, df: pd.DataFrame) -> int:
        """Predict market direction (1=bullish, 0=bearish)."""
        if not self.trained:
            return 0
        
        df = self.engineer_features(df)
        latest = df[self.feature_names].iloc[-1:].values
        latest = self.scaler.transform(latest)
        
        rf_pred = self.rf_model.predict(latest)[0]
        xgb_pred = self.xgb_model.predict(latest)[0]
        
        # Ensemble: both must agree
        if rf_pred == xgb_pred:
            return int(rf_pred)
        
        # Use probabilities
        rf_proba = self.rf_model.predict_proba(latest)[0]
        xgb_proba = self.xgb_model.predict_proba(latest)[0]
        avg_proba = (rf_proba + xgb_proba) / 2
        
        return 1 if avg_proba[1] > 0.55 else 0


# ═══════════════════════════════════════════════════════════════════════════
#                         DEEP LEARNING MODEL CLASS
# ═══════════════════════════════════════════════════════════════════════════

class DLModel:
    """
    LSTM neural network for price prediction.
    """
    
    def __init__(self, lookback: int = 60):
        self.model = None
        self.scaler = StandardScaler()
        self.lookback = lookback
        self.trained = False
        
    def prepare_data(self, df: pd.DataFrame) -> Tuple:
        """Prepare sequential data for LSTM."""
        features = ['close', 'high', 'low', 'tick_volume', 'open']
        data = df[features].values
        data_scaled = self.scaler.fit_transform(data)
        
        X, y = [], []
        for i in range(self.lookback, len(data_scaled)):
            X.append(data_scaled[i-self.lookback:i])
            y.append(data_scaled[i, 0])
        
        X, y = np.array(X), np.array(y)
        
        split = int(len(X) * 0.8)
        return X[:split], X[split:], y[:split], y[split:]
    
    def build_model(self, input_shape: Tuple) -> Sequential:
        """Build LSTM architecture."""
        model = Sequential([
            LSTM(50, return_sequences=True, input_shape=input_shape),
            Dropout(0.2),
            LSTM(50, return_sequences=False),
            Dropout(0.2),
            Dense(25, activation='relu'),
            Dense(1)
        ])
        model.compile(optimizer='adam', loss='mse', metrics=['mae'])
        return model
    
    def train(self, df: pd.DataFrame):
        """Train LSTM model."""
        
        X_train, X_test, y_train, y_test = self.prepare_data(df)
        self.model = self.build_model((X_train.shape[1], X_train.shape[2]))
        
        early_stop = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)
        
        self.model.fit(
            X_train, y_train,
            epochs=30,
            batch_size=32,
            validation_data=(X_test, y_test),
            callbacks=[early_stop],
            verbose=0
        )
        
        self.trained = True
        print("    ✓ LSTM training complete")
    
    def predict_next_price(self, df: pd.DataFrame) -> float:
        """Predict next close price."""
        if not self.trained:
            return df['close'].iloc[-1]
        
        features = ['close', 'high', 'low', 'tick_volume', 'open']
        data = df[features].tail(self.lookback).values
        data_scaled = self.scaler.transform(data)
        data_scaled = data_scaled.reshape(1, self.lookback, len(features))
        
        pred_scaled = self.model.predict(data_scaled, verbose=0)[0][0]
        
        # Inverse transform
        dummy = np.zeros((1, len(features)))
        dummy[0, 0] = pred_scaled
        pred = self.scaler.inverse_transform(dummy)[0, 0]
        
        return pred


# ═══════════════════════════════════════════════════════════════════════════
#                         TECHNICAL ANALYSIS CLASS
# ═══════════════════════════════════════════════════════════════════════════

class TechnicalAnalysis:
    """
    Support/Resistance detection and technical calculations.
    """
    
    @staticmethod
    def find_support_resistance(df: pd.DataFrame) -> Dict:
        """Detect support and resistance levels."""
        # Local minima (support)
        df = df.copy()
        df['local_min'] = df['low'][(df['low'].shift(1) > df['low']) & (df['low'].shift(-1) > df['low'])]
        df['local_max'] = df['high'][(df['high'].shift(1) < df['high']) & (df['high'].shift(-1) < df['high'])]
        
        recent_support = df['local_min'].dropna().tail(5).tolist()
        recent_resistance = df['local_max'].dropna().tail(5).tolist()
        
        # Pivot points
        high = df['high'].iloc[-1]
        low = df['low'].iloc[-1]
        close = df['close'].iloc[-1]
        pivot = (high + low + close) / 3
        
        r1 = (2 * pivot) - low
        s1 = (2 * pivot) - high
        
        current_price = df['close'].iloc[-1]
        
        all_support = recent_support + [s1]
        all_resistance = recent_resistance + [r1]
        
        nearest_support = max([s for s in all_support if s < current_price], default=s1)
        nearest_resistance = min([r for r in all_resistance if r > current_price], default=r1)
        
        return {
            'support': nearest_support,
            'resistance': nearest_resistance,
            'pivot': pivot,
            'all_support': all_support,
            'all_resistance': all_resistance
        }
    
    @staticmethod
    def calculate_atr(df: pd.DataFrame, period: int = 14) -> float:
        """Calculate Average True Range."""
        high_low = df['high'] - df['low']
        high_close = np.abs(df['high'] - df['close'].shift())
        low_close = np.abs(df['low'] - df['close'].shift())
        ranges = pd.concat([high_low, high_close, low_close], axis=1)
        true_range = np.max(ranges, axis=1)
        return true_range.rolling(period).mean().iloc[-1]


# ═══════════════════════════════════════════════════════════════════════════
#                           TRADE DASHBOARD CLASS
# ═══════════════════════════════════════════════════════════════════════════

class TradeDashboard:
    """
    Performance metrics and visualization dashboard.
    """
    
    @staticmethod
    def generate_report(mt5_manager: MT5Manager, positions: List[Dict],
                       closed_trades: List[Dict]) -> str:
        """Generate comprehensive dashboard."""
        account = mt5_manager.account_info
        
        report = "\\n" + "="*80 + "\\n"
        report += "MANIQUANTCRYPTO BOT - TRADING DASHBOARD".center(80) + "\\n"
        report += "="*80 + "\\n"
        report += f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\\n"
        
        # Account Summary
        report += "\\n" + "-"*80 + "\\n"
        report += "ACCOUNT SUMMARY\\n"
        report += "-"*80 + "\\n"
        report += f"Balance:          \${account.balance:,.2f}\\n"
        report += f"Equity:           \${account.equity:,.2f}\\n"
        report += f"Margin Used:      \${account.margin:,.2f}\\n"
        report += f"Free Margin:      \${account.margin_free:,.2f}\\n"
        report += f"Floating P/L:     \${account.profit:,.2f}\\n"
        report += f"Allocated:        \${mt5_manager.allocated_capital:,.2f} ({mt5_manager.allocation_percentage*100:.1f}%)\\n"
        
        # Performance metrics
        total_return = account.balance - mt5_manager.initial_balance
        return_pct = (total_return / mt5_manager.initial_balance) * 100
        report += f"Total Return:     \${total_return:,.2f} ({return_pct:+.2f}%)\\n"
        
        # Open Positions
        report += "\\n" + "-"*80 + "\\n"
        report += f"OPEN POSITIONS ({len(positions)})\\n"
        report += "-"*80 + "\\n"
        
        if positions:
            for pos in positions:
                report += f"\\nTicket #{pos['ticket']}:\\n"
                report += f"  Symbol:        {pos['symbol']}\\n"
                report += f"  Type:          {pos['type']}\\n"
                report += f"  Volume:        {pos['volume']:.2f} lots\\n"
                report += f"  Open Price:    \${pos['price_open']:.2f}\\n"
                report += f"  Current Price: \${pos['price_current']:.2f}\\n"
                report += f"  Stop Loss:     \${pos['sl']:.2f}\\n"
                report += f"  Take Profit:   \${pos['tp']:.2f}\\n"
                report += f"  Profit/Loss:   \${pos['profit']:.2f}\\n"
        else:
            report += "No open positions\\n"
        
        # Statistics
        if closed_trades:
            report += "\\n" + "-"*80 + "\\n"
            report += "PERFORMANCE STATISTICS\\n"
            report += "-"*80 + "\\n"
            
            profits = [t['profit'] for t in closed_trades]
            wins = [p for p in profits if p > 0]
            losses = [p for p in profits if p < 0]
            
            win_rate = (len(wins) / len(profits)) * 100 if profits else 0
            avg_win = np.mean(wins) if wins else 0
            avg_loss = abs(np.mean(losses)) if losses else 0
            profit_factor = abs(sum(wins) / sum(losses)) if losses and sum(losses) != 0 else 0
            
            report += f"Total Trades:     {len(profits)}\\n"
            report += f"Winning Trades:   {len(wins)}\\n"
            report += f"Losing Trades:    {len(losses)}\\n"
            report += f"Win Rate:         {win_rate:.2f}%\\n"
            report += f"Average Win:      \${avg_win:.2f}\\n"
            report += f"Average Loss:     \${avg_loss:.2f}\\n"
            report += f"Profit Factor:    {profit_factor:.2f}\\n"
            report += f"Total P/L:        \${sum(profits):.2f}\\n"
        
        report += "\\n" + "="*80 + "\\n"
        return report
    
    @staticmethod
    def save_html_report(report: str, filename: str = "dashboard.html"):
        """Save dashboard as HTML."""
        html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>ManiquantCrypto Dashboard</title>
    <style>
        body {{ font-family: 'Courier New', monospace; background: #1a1a1a; color: #00ff00; padding: 20px; }}
        pre {{ background: #000; padding: 20px; border-radius: 8px; border: 2px solid #00ff00; }}
        h1 {{ color: #00ff00; text-align: center; }}
    </style>
</head>
<body>
    <h1>📊 ManiquantCrypto Bot Dashboard</h1>
    <pre>{report}</pre>
</body>
</html>
        """
        with open(filename, 'w') as f:
            f.write(html)
        print(f"  ✓ Dashboard saved: {filename}")


# ═══════════════════════════════════════════════════════════════════════════
#                          MAIN BOT ORCHESTRATOR
# ═══════════════════════════════════════════════════════════════════════════

class ManiquantCryptoBot:
    """
    Main trading bot that orchestrates all components.
    """
    
    def __init__(self, symbols: List[str], timeframe: int = mt5.TIMEFRAME_H1):
        self.symbols = symbols
        self.timeframe = timeframe
        self.mt5 = MT5Manager()
        self.ml_models = {}
        self.dl_models = {}
        self.closed_trades = []
        
        # Risk parameters
        self.risk_per_trade = 0.02  # 2%
        self.risk_reward_ratio = 2.0  # 1:2
        self.max_positions = 3
        self.min_confidence = 0.55
        
    def initialize(self) -> bool:
        """Initialize bot components."""
        print("""
╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║                    MANIQUANTCRYPTO BOT v1.0                               ║
║                                                                           ║
║  ⚠️  CRYPTOCURRENCY TRADING RISK WARNING ⚠️                               ║
║                                                                           ║
║  • High risk of losing your entire investment                            ║
║  • Volatile markets can cause rapid losses                               ║
║  • Leverage magnifies both profits and losses                            ║
║  • Past performance does not guarantee future results                    ║
║  • Only trade with capital you can afford to lose                        ║
║                                                                           ║
║  This software is provided for educational purposes only.                ║
║  By continuing, you accept full responsibility for all trading decisions.║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝
        """)
        
        accept = input("Do you accept these risks and wish to continue? (yes/no): ")
        if accept.lower() != 'yes':
            print("\\nBot initialization cancelled. Stay safe!")
            return False
        
        # Connect to MT5
        if not self.mt5.initialize_connection():
            return False
        
        # Get capital allocation
        if not self.mt5.get_capital_allocation():
            return False
        
        # Train models
        print("\\n" + "="*80)
        print("MODEL TRAINING & INITIALIZATION".center(80))
        print("="*80)
        
        total_symbols = len(self.symbols)
        success_count = 0
        
        for i, symbol in enumerate(self.symbols):
            # Progress Indicator
            percent = ((i) / total_symbols) * 100
            bar_len = 30
            filled_len = int(bar_len * percent / 100)
            bar = '█' * filled_len + '-' * (bar_len - filled_len)
            
            print(f"\\nProcessing {symbol} [{bar}] {int(percent)}%")
            print(f"→ Fetching market data for {symbol}...")
            
            try:
                df = self.mt5.get_historical_data(symbol, self.timeframe, 1000)
                if df is None or len(df) < 200:
                    print(f"  ⚠ Insufficient data for {symbol}. Skipping.")
                    continue
                
                print(f"  ✓ Data loaded: {len(df)} candles")
                
                # Train ML
                try:
                    print(f"  → Training Machine Learning Ensemble...")
                    ml = MLModel()
                    ml.train(df)
                    self.ml_models[symbol] = ml
                except Exception as e:
                    print(f"  ✗ ML Training Error for {symbol}: {e}")

                # Train DL
                try:
                    print(f"  → Training Deep Learning LSTM Network...")
                    dl = DLModel()
                    dl.train(df)
                    self.dl_models[symbol] = dl
                except Exception as e:
                    print(f"  ✗ DL Training Error for {symbol}: {e}")
                
                if symbol in self.ml_models or symbol in self.dl_models:
                    success_count += 1
                    print(f"  ✓ {symbol} initialization complete.")
                else:
                    print(f"  ✗ Failed to initialize any models for {symbol}.")
                    
            except Exception as e:
                print(f"  ✗ Critical error processing {symbol}: {e}")
                continue
        
        print("\\n" + "-"*80)
        if success_count == 0:
            print("✗ CRITICAL: No models could be trained. Exiting.")
            return False
        
        print(f"✓ Initialization Complete. {success_count}/{total_symbols} symbols ready for trading.")
        return True
    
    def generate_signal(self, symbol: str, df: pd.DataFrame) -> Dict:
        """Generate trading signal."""
        # ML prediction
        ml_pred = 0
        if symbol in self.ml_models:
             ml_pred = self.ml_models[symbol].predict(df)
        
        # DL prediction
        dl_pred = 0
        predicted_price = df['close'].iloc[-1]
        
        if symbol in self.dl_models:
            current_price = df['close'].iloc[-1]
            predicted_price = self.dl_models[symbol].predict_next_price(df)
            dl_pred = 1 if predicted_price > current_price else 0
        
        # Technical levels
        levels = TechnicalAnalysis.find_support_resistance(df)
        atr = TechnicalAnalysis.calculate_atr(df)
        
        # Signal determination
        # Relaxed logic: If one model is missing, rely on the other
        signal = 'NEUTRAL'
        confidence = 'LOW'

        if symbol in self.ml_models and symbol in self.dl_models:
            if ml_pred == dl_pred == 1:
                signal = 'BUY'
                confidence = 'HIGH'
            elif ml_pred == dl_pred == 0:
                signal = 'SELL'
                confidence = 'HIGH'
        elif symbol in self.ml_models:
             if ml_pred == 1: signal = 'BUY'
             elif ml_pred == 0: signal = 'SELL'
             confidence = 'MEDIUM'
        
        # Check proximity to S/R
        current_price = df['close'].iloc[-1]
        near_support = abs(current_price - levels['support']) / current_price < 0.01
        near_resistance = abs(current_price - levels['resistance']) / current_price < 0.01
        
        return {
            'signal': signal,
            'confidence': confidence,
            'price': current_price,
            'predicted': predicted_price,
            'support': levels['support'],
            'resistance': levels['resistance'],
            'atr': atr,
            'near_support': near_support,
            'near_resistance': near_resistance
        }
    
    def execute_logic(self, symbol: str, signal_data: Dict) -> bool:
        """Execute trading decision."""
        signal = signal_data['signal']
        confidence = signal_data['confidence']
        
        # Only trade high confidence setups
        if confidence != 'HIGH':
            return False
        
        # Check existing positions
        positions = self.mt5.get_open_positions(symbol)
        if positions or len(self.mt5.get_open_positions()) >= self.max_positions:
            return False
        
        price = signal_data['price']
        atr = signal_data['atr']
        
        # BUY logic
        if signal == 'BUY' and signal_data['near_support']:
            sl = signal_data['support'] - (atr * 1.5)
            risk_points = price - sl
            tp = price + (risk_points * self.risk_reward_ratio)
            
            risk_amount = self.mt5.allocated_capital * self.risk_per_trade
            info = self.mt5.get_symbol_info(symbol)
            lot_size = self.mt5.calculate_lot_size(symbol, risk_amount, risk_points / info['point'])
            
            result = self.mt5.execute_trade(symbol, mt5.ORDER_TYPE_BUY, lot_size, sl, tp, "ML/DL Buy")
            
            if result:
                print(f"\\n🟢 BUY {symbol}")
                print(f"  Price: \${result['price']:.2f} | SL: \${sl:.2f} | TP: \${tp:.2f}")
                print(f"  Lot Size: {lot_size:.2f} | Risk: \${risk_amount:.2f}")
                return True
        
        # SELL logic
        elif signal == 'SELL' and signal_data['near_resistance']:
            sl = signal_data['resistance'] + (atr * 1.5)
            risk_points = sl - price
            tp = price - (risk_points * self.risk_reward_ratio)
            
            risk_amount = self.mt5.allocated_capital * self.risk_per_trade
            info = self.mt5.get_symbol_info(symbol)
            lot_size = self.mt5.calculate_lot_size(symbol, risk_amount, risk_points / info['point'])
            
            result = self.mt5.execute_trade(symbol, mt5.ORDER_TYPE_SELL, lot_size, sl, tp, "ML/DL Sell")
            
            if result:
                print(f"\\n🔴 SELL {symbol}")
                print(f"  Price: \${result['price']:.2f} | SL: \${sl:.2f} | TP: \${tp:.2f}")
                print(f"  Lot Size: {lot_size:.2f} | Risk: \${risk_amount:.2f}")
                return True
        
        return False
    
    def run(self):
        """Main trading loop."""
        print("\\n" + "="*80)
        print("LIVE TRADING ACTIVE".center(80))
        print("="*80)
        print(f"Symbols: {', '.join(self.symbols)}")
        print(f"Timeframe: {self.timeframe}")
        print("Press Ctrl+C to stop\\n")
        
        iteration = 0
        
        try:
            while True:
                iteration += 1
                print(f"\\n{'='*80}")
                print(f"Iteration {iteration} | {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}".center(80))
                print(f"{'='*80}")
                
                for symbol in self.symbols:
                    # Skip if no models for this symbol
                    if symbol not in self.ml_models and symbol not in self.dl_models:
                        continue
                    
                    print(f"\\n→ Analyzing {symbol}...")
                    
                    try:
                        df = self.mt5.get_historical_data(symbol, self.timeframe, 200)
                        if df is None:
                            continue
                        
                        signal_data = self.generate_signal(symbol, df)
                        
                        print(f"  Signal: {signal_data['signal']} ({signal_data['confidence']})")
                        print(f"  Price: \${signal_data['price']:.2f}")
                        print(f"  Support: \${signal_data['support']:.2f} | Resistance: \${signal_data['resistance']:.2f}")
                        
                        self.execute_logic(symbol, signal_data)
                    except Exception as e:
                        print(f"  ⚠ Error analyzing {symbol}: {e}")
                        continue
                
                # Dashboard every 5 iterations
                if iteration % 5 == 0:
                    positions = self.mt5.get_open_positions()
                    report = TradeDashboard.generate_report(self.mt5, positions, self.closed_trades)
                    print(report)
                    TradeDashboard.save_html_report(report)
                
                # Wait for next candle
                wait_time = 3600  # 1 hour
                print(f"\\n⏳ Waiting {wait_time//60} minutes...")
                time.sleep(wait_time)
                
        except KeyboardInterrupt:
            print("\\n\\n⏸ Bot stopped by user")
            self.shutdown()
    
    def shutdown(self):
        """Final cleanup."""
        print("\\n" + "="*80)
        print("SHUTDOWN".center(80))
        print("="*80)
        
        positions = self.mt5.get_open_positions()
        report = TradeDashboard.generate_report(self.mt5, positions, self.closed_trades)
        print(report)
        TradeDashboard.save_html_report(report, "final_report.html")
        
        self.mt5.shutdown()
        print("\\n✓ Bot shutdown complete")


# ═══════════════════════════════════════════════════════════════════════════
#                              MAIN EXECUTION
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    # Configuration
    SYMBOLS = ['BTCUSD', 'ETHUSD', 'XRPUSD', 'SOLUSD']  # Add more symbols as needed
    TIMEFRAME = mt5.TIMEFRAME_H1     # Options: M1, M5, M15, M30, H1, H4, D1
    
    # Create and run bot
    bot = ManiquantCryptoBot(symbols=SYMBOLS, timeframe=TIMEFRAME)
    
    if bot.initialize():
        bot.run()
    else:
        print("\\n✗ Bot initialization failed")`;
