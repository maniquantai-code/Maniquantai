
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://zuimeyynaarjsovnqilk.supabase.co';
const supabaseKey = 'sb_publishable_Uf0ECWKVkKrH6pzedVbTOA_aNlp1J1X';

export const supabase = createClient(supabaseUrl, supabaseKey);
