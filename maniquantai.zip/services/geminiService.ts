
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, DeepAnalysisResult, Investor, NewsItem, BacktestResult, BacktestParameter } from '../types';

const cleanJson = (text: string): string => {
  if (!text) return "";
  let cleaned = text.replace(/```json\n?/g, '').replace(/```/g, '').trim();
  const firstSquare = cleaned.indexOf('[');
  const lastSquare = cleaned.lastIndexOf(']');
  const firstCurly = cleaned.indexOf('{');
  const lastCurly = cleaned.lastIndexOf('}');

  if (firstSquare !== -1 && lastSquare !== -1) {
      if (firstCurly === -1 || firstSquare < firstCurly) {
          return cleaned.substring(firstSquare, lastSquare + 1);
      }
  }
  if (firstCurly !== -1 && lastCurly !== -1) {
      return cleaned.substring(firstCurly, lastCurly + 1);
  }
  return cleaned;
};

export const analyzeChartImage = async (
  base64Image: string, 
  options: { chartType: string; focusIndicators: string[]; precision?: string }
): Promise<AnalysisResult> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = 'gemini-3-flash-preview';
    const cleanBase64 = base64Image.split(',')[1] || base64Image;

    const prompt = `
      As 'ManiquantAi', analyze this ${options.chartType} chart.
      Identify trend, support, resistance, and provide a trading strategy.
      Return strictly valid JSON.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/png', data: cleanBase64 } },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
            type: Type.OBJECT,
            properties: {
                strategy: { type: Type.STRING },
                confidence: { type: Type.NUMBER },
                trend: { type: Type.STRING },
                profitability: { type: Type.STRING },
                stopLoss: { type: Type.STRING },
                takeProfit: { type: Type.STRING },
                support: { type: Type.STRING },
                resistance: { type: Type.STRING },
                indicators: { type: Type.ARRAY, items: { type: Type.STRING } },
                reasoning: { type: Type.STRING }
            },
            required: ['strategy', 'confidence', 'trend', 'stopLoss', 'takeProfit', 'reasoning']
        }
      }
    });

    return JSON.parse(cleanJson(response.text)) as AnalysisResult;
  } catch (error) {
    console.error("Analysis Error:", error);
    throw error;
  }
};

/**
 * Institutional Deep Dive Analysis using Pro model
 */
export const getDeepChartAnalysis = async (
  base64Image: string, 
  initialResult: AnalysisResult
): Promise<DeepAnalysisResult> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = 'gemini-3-pro-preview';
    const cleanBase64 = base64Image.split(',')[1] || base64Image;

    const prompt = `
      SYSTEM: INSTITUTIONAL QUANT ARCHITECT MODE.
      TASK: Perform a deep structural analysis on this chart based on initial findings: ${JSON.stringify(initialResult)}.
      
      FOCUS AREAS:
      1. Market Micro-Structure: Wyckoff, Market Cycles.
      2. Institutional Bias: Where is the Smart Money (SMC) positioned? 
      3. Liquidity Zones: Major pools where price will likely gravitate.
      4. Risk-to-Reward Matrix: Tiers of profit targets with specific R:R calculations.
      5. Invalidation Criteria: Precise price behavior that voids the current bullish/bearish bias.
      
      OUTPUT: Strict JSON for DeepAnalysisResult interface.
    `;

    const response = await ai.models.generateContent({
      model,
      contents: {
        parts: [
          { inlineData: { mimeType: 'image/png', data: cleanBase64 } },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            marketStructure: { type: Type.STRING },
            institutionalBias: { type: Type.STRING },
            liquidityZones: { type: Type.ARRAY, items: { type: Type.STRING } },
            riskMatrix: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  tier: { type: Type.STRING },
                  target: { type: Type.STRING },
                  rrRatio: { type: Type.STRING }
                }
              }
            },
            invalidationCriteria: { type: Type.STRING },
            macroContext: { type: Type.STRING }
          },
          required: ['marketStructure', 'institutionalBias', 'liquidityZones', 'riskMatrix', 'invalidationCriteria']
        }
      }
    });

    return JSON.parse(cleanJson(response.text)) as DeepAnalysisResult;
  } catch (error) {
    console.error("Deep Analysis Error:", error);
    throw error;
  }
};

export const getInvestmentSimulation = async (amount: number, marketType: string = 'STOCKS'): Promise<any[]> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = 'gemini-3-flash-preview';
    const response = await ai.models.generateContent({
      model,
      contents: `Create a portfolio allocation for ₹${amount} in ${marketType}. Return ONLY JSON array of {name, value}.`,
      config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(cleanJson(response.text));
  } catch (error) {
    return [{ name: "Defensive", value: amount }];
  }
};

export const parseInvestorData = async (csvText: string): Promise<Investor[]> => {
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const model = 'gemini-3-flash-preview';
        const response = await ai.models.generateContent({
            model,
            contents: `Extract investors as JSON array from: ${csvText.substring(0, 2000)}`,
            config: { responseMimeType: 'application/json' }
        });
        return JSON.parse(cleanJson(response.text));
    } catch (error) { return []; }
}

export const fetchMoreInvestors = async (): Promise<Investor[]> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = 'gemini-3-flash-preview';
    const response = await ai.models.generateContent({
      model,
      contents: `Find 4 unique famous investors. Return JSON array.`,
      config: { tools: [{ googleSearch: {} }], responseMimeType: "application/json" }
    });
    return JSON.parse(cleanJson(response.text));
  } catch (error) { return []; }
};

export const fetchMarketNews = async (): Promise<NewsItem[]> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = 'gemini-3-flash-preview';
    const response = await ai.models.generateContent({
      model,
      contents: `Search latest market news. Return JSON array of {id, title, source, time, url}.`,
      config: { tools: [{ googleSearch: {} }], responseMimeType: "application/json" },
    });
    return JSON.parse(cleanJson(response.text));
  } catch (error) { return []; }
};

export const generateAIStrategy = async (constraints: any): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = 'gemini-3-pro-preview';
    const response = await ai.models.generateContent({
      model,
      contents: `Design institutional strategy for: ${JSON.stringify(constraints)}`,
    });
    return response.text;
  } catch (error) { return "Error generating strategy."; }
};

export const getBacktestParameters = async (strategy: string, asset: string, duration: string): Promise<BacktestParameter[]> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = 'gemini-3-pro-preview';
    const response = await ai.models.generateContent({
      model,
      contents: `Identify numeric backtest parameters for: ${strategy}`,
      config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(cleanJson(response.text));
  } catch (error) { return []; }
};

export const runBacktest = async (strategy: string, inputs: any, asset: string, duration: string, currency: string): Promise<BacktestResult> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const model = 'gemini-3-pro-preview';
    const response = await ai.models.generateContent({
      model,
      contents: `Simulate strategy: ${strategy} with ${JSON.stringify(inputs)} on ${asset} for ${duration} in ${currency}.`,
      config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(cleanJson(response.text)) as BacktestResult;
  } catch (error) {
    throw error;
  }
};

export const askAIAdvisor = async (question: string): Promise<string> => {
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const model = 'gemini-3-flash-preview';
        const response = await ai.models.generateContent({
            model,
            contents: question,
            config: { systemInstruction: "You are 'ManiquantAi Advisor'. Institutional expert. End with: 'Hope this will help you.'" }
        });
        return response.text;
    } catch (error) { return "Error. Hope this will help you."; }
};
