
import { PlanType, StockTicker, NewsItem, Investor } from './types';

export const INITIAL_CREDITS = 1;

export const PLANS = {
  [PlanType.FREE]: {
    name: 'Free Trial',
    price: 0,
    period: 'once',
    credits: 1,
    features: ['1 Free AI Analysis', 'Basic Charting', 'Limited Markets'],
  },
  [PlanType.BASIC]: {
    name: 'Standard Monthly',
    price: 100,
    period: 'mo',
    credits: 500,
    features: ['500 Credits / Month', 'Advanced AI Access', 'Email Support'],
  },
  [PlanType.PRO]: {
    name: 'Deprecated',
    price: 0,
    period: 'mo',
    credits: 0,
    features: [],
  },
  [PlanType.ELITE]: {
    name: 'Unlimited Yearly',
    price: 1999,
    period: 'yr',
    credits: 999999, 
    features: ['Unlimited Credits', 'Priority Support', 'Watermarked PDF Reports', 'Early Access Features'],
  },
};

export const MOCK_TICKERS: StockTicker[] = [
  { symbol: 'NIFTY 50', price: '22,450.30', change: 0.85, isPositive: true },
  { symbol: 'SENSEX', price: '73,980.15', change: 0.72, isPositive: true },
  { symbol: 'RELIANCE', price: '2,980.00', change: 1.4, isPositive: true },
  { symbol: 'HDFC BANK', price: '1,442.20', change: -0.8, isPositive: false },
  { symbol: 'TCS', price: '4,120.50', change: 0.25, isPositive: true },
  { symbol: 'INFY', price: '1,620.00', change: -1.2, isPositive: false },
  { symbol: 'S&P 500', price: '5,240.10', change: 0.45, isPositive: true },
  { symbol: 'NASDAQ', price: '16,320.00', change: 0.92, isPositive: true },
  { symbol: 'AAPL', price: '185.20', change: 0.15, isPositive: true },
  { symbol: 'NVDA', price: '890.00', change: 2.45, isPositive: true },
  { symbol: 'BTC/USD', price: '67,430.00', change: -1.2, isPositive: false },
  { symbol: 'ETH/USD', price: '3,540.20', change: -0.5, isPositive: false },
  { symbol: 'GOLD', price: '2,350.50', change: 1.1, isPositive: true },
  { symbol: 'CRUDE OIL', price: '82.40', change: -0.3, isPositive: false },
];

export const MOCK_INVESTORS: Investor[] = [
  {
    name: "Rakesh Jhunjhunwala",
    strategy: "Multibagger Value Hunter",
    location: "INDIAN",
    roi: "32% CAGR",
    imageUrl: "",
    platform: "Rare Enterprises",
    philosophy: "Invest in a business, not a stock. Buy right and sit tight.",
    portfolio: [
      { company: "Titan Company", ticker: "TITAN", allocation: "35%", sector: "Consumer Durables" },
      { company: "Star Health", ticker: "STARHEALTH", allocation: "15%", sector: "Insurance" },
      { company: "Tata Motors", ticker: "TATAMOTORS", allocation: "12%", sector: "Automobile" }
    ]
  },
  {
    name: "Warren Buffett",
    strategy: "Value Investing Legend",
    location: "GLOBAL",
    roi: "20% CAGR",
    imageUrl: "",
    platform: "Berkshire Hathaway",
    philosophy: "Our favorite holding period is forever. Price is what you pay, value is what you get.",
    portfolio: [
      { company: "Apple Inc.", ticker: "AAPL", allocation: "40%", sector: "Technology" },
      { company: "Bank of America", ticker: "BAC", allocation: "12%", sector: "Finance" },
      { company: "Coca-Cola", ticker: "KO", allocation: "8%", sector: "Consumer Goods" }
    ]
  },
  {
    name: "Radhakishan Damani",
    strategy: "Retail & Value Maven",
    location: "INDIAN",
    roi: "28% CAGR",
    imageUrl: "",
    platform: "Derive Investments",
    philosophy: "Focus on the long term and maintain strict financial discipline.",
    portfolio: [
      { company: "Avenue Supermarts", ticker: "DMART", allocation: "65%", sector: "Retail" },
      { company: "Trent Ltd", ticker: "TRENT", allocation: "10%", sector: "Retail" },
      { company: "VST Industries", ticker: "VSTIND", allocation: "5%", sector: "FMCG" }
    ]
  },
  {
    name: "Ray Dalio",
    strategy: "Macro & Risk Parity",
    location: "GLOBAL",
    roi: "15% CAGR",
    imageUrl: "",
    platform: "Bridgewater Associates",
    philosophy: "Principles are fundamental truths that serve as the foundations for behavior.",
    portfolio: [
      { company: "P&G", ticker: "PG", allocation: "5%", sector: "Consumer Staples" },
      { company: "Johnson & Johnson", ticker: "JNJ", allocation: "4%", sector: "Healthcare" },
      { company: "Gold ETF", ticker: "GLD", allocation: "10%", sector: "Commodity" }
    ]
  },
  {
    name: "Mohnish Pabrai",
    strategy: "The Dhando Investor",
    location: "INDIAN",
    roi: "25% CAGR",
    imageUrl: "",
    platform: "Pabrai Investment Funds",
    philosophy: "Heads I win, tails I don't lose much. Always look for low risk, high uncertainty.",
    portfolio: [
      { company: "Reisun Corp", ticker: "REISUN", allocation: "20%", sector: "Infrastructure" },
      { company: "Micron Tech", ticker: "MU", allocation: "15%", sector: "Technology" },
      { company: "Edelweiss", ticker: "EDELWEISS", allocation: "10%", sector: "Finance" }
    ]
  }
];

export const MOCK_NEWS: NewsItem[] = [
  { 
    id: 1, 
    title: 'RBI maintains status quo on repo rate', 
    source: 'Finance India', 
    time: '2h ago',
    url: 'https://economictimes.indiatimes.com/topic/repo-rate'
  },
  { 
    id: 2, 
    title: 'Bitcoin surges past resistance levels as halving approaches', 
    source: 'CryptoDaily', 
    time: '4h ago',
    url: 'https://cointelegraph.com/tags/bitcoin'
  },
  { 
    id: 3, 
    title: 'Gold hits all-time high amidst global uncertainty', 
    source: 'Commodity Watch', 
    time: '5h ago',
    url: 'https://www.kitco.com/news/commodities'
  },
];

export const BOT_NAME = "ManiquantAi";
