
export enum PlanType {
  FREE = 'FREE',
  BASIC = 'BASIC',
  PRO = 'PRO',
  ELITE = 'ELITE'
}

export interface UserState {
  credits: number;
  plan: PlanType;
  autoPayEnabled: boolean;
}

export interface PortfolioItem {
  company: string;
  ticker: string;
  allocation: string;
  sector: string;
}

export interface AnalysisResult {
  strategy: string;
  confidence: number;
  trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL' | 'SIDEWAYS';
  profitability: string;
  stopLoss: string;
  takeProfit: string;
  support: string;
  resistance: string;
  indicators: string[];
  reasoning: string;
  technicalSignals?: {
    rsi?: string;
    macd?: string;
    bollinger?: string;
  };
}

export interface DeepAnalysisResult {
  marketStructure: string;
  institutionalBias: string;
  liquidityZones: string[];
  riskMatrix: {
    tier: string;
    target: string;
    rrRatio: string;
  }[];
  invalidationCriteria: string;
  macroContext: string;
}

export interface StockTicker {
  symbol: string;
  price: string;
  change: number;
  isPositive: boolean;
}

export interface NewsItem {
  id: number;
  title: string;
  source: string;
  time: string;
  url: string;
}

export interface Investor {
  name: string;
  strategy: string;
  imageUrl: string;
  roi: string;
  philosophy: string;
  platform: string;
  location: 'GLOBAL' | 'INDIAN';
  portfolio: PortfolioItem[];
}

export interface BacktestParameter {
  id: string;
  question: string;
  defaultValue: string;
}

export interface BacktestResult {
  equityCurve: { date: string; equity: number }[];
  metrics: {
    netProfit: string;
    winRate: string;
    profitFactor: string;
    maxDrawdown: string;
    totalTrades: number;
  };
  analysis: string;
  verdict: 'PROFITABLE' | 'UNPROFITABLE' | 'RISKY';
}
