import React, { useState, useEffect } from 'react';
import { Key } from 'lucide-react';

interface ConnectExchangeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnect: (exchange: string, apiKey: string, apiSecret: string) => void;
  defaultExchange?: string;
}

const ConnectExchangeModal: React.FC<ConnectExchangeModalProps> = ({ 
  isOpen, 
  onClose, 
  onConnect, 
  defaultExchange = 'MT5' 
}) => {
  const [exchange, setExchange] = useState(defaultExchange);
  const [apiKey, setApiKey] = useState('');
  const [apiSecret, setApiSecret] = useState('');

  // Update exchange when defaultExchange prop changes or modal opens
  useEffect(() => {
    if (isOpen) {
      setExchange('MT5');
      setApiKey('');
      setApiSecret('');
    }
  }, [isOpen, defaultExchange]);

  if (!isOpen) return null;

  const handleSubmit = () => {
    if (!apiKey || !apiSecret) {
      alert("Please provide both Login ID and Password.");
      return;
    }
    onConnect(exchange, apiKey, apiSecret);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4 backdrop-blur-md">
      <div className="bg-black border border-slate-700 p-6 rounded-xl w-full max-w-md shadow-2xl shadow-neon-green/10">
        <div className="flex items-center space-x-2 mb-6">
           <div className="p-2 bg-slate-900 rounded-lg border border-slate-700">
             <Key size={20} className="text-neon-green" />
           </div>
           <h3 className="text-xl font-bold font-tech text-white">Connect {exchange}</h3>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs text-slate-400 mb-1">Trading Platform</label>
            <select 
              value={exchange}
              onChange={(e) => setExchange(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 p-3 rounded text-white focus:border-neon-green outline-none"
              disabled
            >
              <option value="MT5">MetaTrader 5</option>
            </select>
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">MT5 Login ID</label>
            <input 
              type="text" 
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="Enter account number" 
              className="w-full bg-slate-900 border border-slate-700 p-3 rounded text-white focus:border-neon-green outline-none font-mono text-sm" 
            />
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Password</label>
            <input 
              type="password" 
              value={apiSecret}
              onChange={(e) => setApiSecret(e.target.value)}
              placeholder="Enter password" 
              className="w-full bg-slate-900 border border-slate-700 p-3 rounded text-white focus:border-neon-green outline-none font-mono text-sm" 
            />
          </div>
        </div>

        <div className="flex justify-end gap-3 mt-8">
          <button 
            onClick={onClose} 
            className="px-4 py-2 text-slate-400 hover:text-white transition-colors"
          >
            Cancel
          </button>
          <button 
            onClick={handleSubmit}
            className="px-6 py-2 bg-neon-green text-black font-bold rounded hover:bg-[#00cc55] transition-all font-tech"
          >
            ESTABLISH LINK
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConnectExchangeModal;