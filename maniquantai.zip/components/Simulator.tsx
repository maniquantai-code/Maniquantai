
import React, { useState } from 'react';
import { getInvestmentSimulation, getBacktestParameters, runBacktest, generateAIStrategy } from '../services/geminiService';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as ReTooltip, Legend, XAxis, YAxis, CartesianGrid, Area, AreaChart } from 'recharts';
import { History, Bitcoin, Globe, Terminal, AlertTriangle, Sparkles, ChevronRight, BrainCircuit, BarChart2, MousePointer2, Settings, ArrowLeft, Play, RefreshCw, Target, TrendingUp, CheckCircle2, XCircle, Wallet, DollarSign } from 'lucide-react';
import { BacktestParameter, BacktestResult } from '../types';

interface SimulatorProps {
    hasCredits: boolean;
    consumeCredit: () => void;
    openPricing: () => void;
}

// Colors matching the user's latest screenshot
const ALLOC_COLORS = ['#00f3ff', '#0aff68', '#bc13fe', '#fbbf24', '#2563eb', '#ef4444'];

const MARKETS = [
    { id: 'STOCKS', label: 'INDIAN STOCKS', icon: TrendingUp, color: 'text-neon-green', border: 'border-neon-green' },
    { id: 'CRYPTO', label: 'CRYPTO ASSETS', icon: Bitcoin, color: 'text-neon-blue', border: 'border-neon-blue' },
    { id: 'FOREX', label: 'GLOBAL FOREX', icon: Globe, color: 'text-neon-purple', border: 'border-neon-purple' },
];

const CURRENCIES = [
    { code: 'USD', symbol: '$', label: 'USD ($)' },
    { code: 'INR', symbol: '₹', label: 'INR (₹)' },
    { code: 'EUR', symbol: '€', label: 'EUR (€)' },
    { code: 'GBP', symbol: '£', label: 'GBP (£)' },
    { code: 'USDT', symbol: '₮', label: 'USDT (₮)' },
];

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#050505] border border-white/10 p-4 rounded-2xl shadow-2xl flex flex-col items-center justify-center min-w-[180px]">
        <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest mb-1">{payload[0].name}</p>
        <p className="text-xl font-tech font-bold text-white tracking-wider">
          ₹{Number(payload[0].value).toLocaleString()}
        </p>
        <div className="w-8 h-1 bg-neon-blue rounded-full mt-2 opacity-50"></div>
      </div>
    );
  }
  return null;
};

const Simulator: React.FC<SimulatorProps> = ({ hasCredits, consumeCredit, openPricing }) => {
    const [activeTab, setActiveTab] = useState<'ALLOCATOR' | 'BACKTESTER'>('ALLOCATOR');
    const [amount, setAmount] = useState('');
    const [marketType, setMarketType] = useState('STOCKS');
    const [allocData, setAllocData] = useState<any[]>([]);
    const [allocLoading, setAllocLoading] = useState(false);

    // Backtest states
    const [btStep, setBtStep] = useState<'CHOICE' | 'AI_CONFIG' | 'INPUT' | 'PARAMS' | 'RESULT'>('CHOICE');
    const [btLoading, setBtLoading] = useState(false);
    const [btCurrency, setBtCurrency] = useState('USD');
    const [strategyDesc, setStrategyDesc] = useState('');
    const [assetName, setAssetName] = useState('NIFTY 50');
    const [duration, setDuration] = useState('1 Year');
    const [aiConstraints, setAiConstraints] = useState({ 
        risk: 'Medium', 
        style: 'Swing', 
        outlook: 'Bullish',
        riskPercent: '2',
        maxDrawdown: '10',
        profitFactor: '1.5'
    });
    const [btParams, setBtParams] = useState<BacktestParameter[]>([]);
    const [btParamValues, setBtParamValues] = useState<Record<string, string>>({});
    const [btResult, setBtResult] = useState<BacktestResult | null>(null);

    const handleSimulateAllocation = async () => {
        if (!amount || !hasCredits) { !hasCredits && openPricing(); return; }
        setAllocLoading(true);
        try {
            const res = await getInvestmentSimulation(Number(amount), marketType);
            setAllocData(Array.isArray(res) ? res : []);
            consumeCredit();
        } finally { setAllocLoading(false); }
    };

    const handleGenerateAiStrategy = async () => {
        if (!hasCredits) { openPricing(); return; }
        setBtLoading(true);
        try {
            const strategy = await generateAIStrategy({
                asset: assetName,
                risk: aiConstraints.risk,
                style: aiConstraints.style,
                outlook: aiConstraints.outlook,
                riskPercent: aiConstraints.riskPercent,
                maxDrawdown: aiConstraints.maxDrawdown,
                profitFactor: aiConstraints.profitFactor
            });
            setStrategyDesc(strategy);
            setBtStep('INPUT');
        } finally { setBtLoading(false); }
    };

    const handleIdentifyParams = async () => {
        if (!strategyDesc || !hasCredits) { !hasCredits && openPricing(); return; }
        setBtLoading(true);
        try {
            const params = await getBacktestParameters(strategyDesc, assetName, duration);
            const safeParams = Array.isArray(params) ? params : [];
            setBtParams(safeParams);
            const initialValues: Record<string, string> = {};
            safeParams.forEach(p => initialValues[p.id] = p.defaultValue);
            setBtParamValues(initialValues);
            setBtStep('PARAMS');
        } finally { setBtLoading(false); }
    };

    const handleRunBacktest = async () => {
        if (!hasCredits) { openPricing(); return; }
        setBtLoading(true);
        try {
            const result = await runBacktest(strategyDesc, btParamValues, assetName, duration, btCurrency);
            setBtResult(result);
            setBtStep('RESULT');
            consumeCredit();
        } finally { setBtLoading(false); }
    };

    const getCurrencySymbol = (code: string) => CURRENCIES.find(c => c.code === code)?.symbol || '$';

    return (
        <div className="w-full max-w-6xl mx-auto space-y-6 md:space-y-12">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div>
                    <h2 className="text-2xl md:text-4xl font-tech font-bold text-white flex items-center uppercase">
                        <History className="mr-3 text-neon-blue" size={24} />
                        ManiquantAi <span className="text-neon-purple ml-2">SIMULATOR</span>
                    </h2>
                    <p className="text-[10px] md:text-xs text-slate-500 uppercase tracking-widest font-mono mt-1">ManiquantAi v4.5 Strategic Matrix</p>
                </div>
                
                <div className="flex w-full md:w-auto bg-slate-900/50 p-1 rounded-xl border border-white/10">
                    <button
                        onClick={() => setActiveTab('ALLOCATOR')}
                        className={`flex-1 md:px-6 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === 'ALLOCATOR' ? 'bg-[#0c1321] text-neon-blue border border-neon-blue/20' : 'text-slate-500 hover:text-white'}`}
                    >
                        Portfolio Allocator
                    </button>
                    <button
                        onClick={() => setActiveTab('BACKTESTER')}
                        className={`flex-1 md:px-6 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === 'BACKTESTER' ? 'bg-[#0c1321] text-neon-purple border border-neon-purple/20' : 'text-slate-500 hover:text-white'}`}
                    >
                        Logic Backtester
                    </button>
                </div>
            </div>

            {activeTab === 'ALLOCATOR' && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-in fade-in duration-500">
                    <div className="space-y-8">
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            {MARKETS.map((m) => (
                                <button
                                    key={m.id}
                                    onClick={() => setMarketType(m.id)}
                                    className={`flex items-center gap-3 p-4 rounded-xl border transition-all ${marketType === m.id ? `bg-[#0c1321] ${m.border} ${m.color}` : 'bg-slate-900/50 border-slate-700 text-slate-500'}`}
                                >
                                    <m.icon size={18} />
                                    <span className="text-[9px] font-bold uppercase tracking-wider">{m.label.split(' ')[0]}</span>
                                </button>
                            ))}
                        </div>

                        <div className="bg-slate-950/50 p-6 rounded-2xl border border-white/5">
                            <label className="block text-[10px] text-neon-blue font-bold uppercase tracking-widest mb-3">Capital Registry (INR)</label>
                            <input 
                                type="number" 
                                value={amount}
                                onChange={(e) => setAmount(e.target.value)}
                                placeholder="Enter allocation amount..."
                                className="w-full bg-[#0a0a0a] border border-slate-800 rounded-xl py-4 px-4 text-white text-xl font-tech focus:border-neon-blue outline-none"
                            />
                        </div>

                        <button 
                            onClick={handleSimulateAllocation}
                            disabled={allocLoading || !amount}
                            className="w-full py-4 rounded-xl bg-gradient-to-r from-neon-blue to-blue-700 text-white font-bold font-tech text-lg tracking-widest transition-all shadow-lg active:scale-95 disabled:opacity-50"
                        >
                            {allocLoading ? 'CALCULATING...' : 'INITIATE ALLOCATION'}
                        </button>
                    </div>

                    <div className="bg-[#0c1321]/60 rounded-[3rem] border border-white/10 min-h-[400px] flex flex-col items-center justify-center p-8 relative overflow-hidden shadow-2xl">
                        <div className="absolute inset-0 bg-neon-blue/5 blur-[120px] rounded-full translate-x-1/2"></div>
                        
                        {allocData.length > 0 ? (
                            <div className="w-full h-full flex flex-col items-center">
                                <div className="relative w-full h-[300px] flex items-center justify-center">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <PieChart>
                                            <Pie 
                                                data={allocData} 
                                                innerRadius={80} 
                                                outerRadius={120} 
                                                paddingAngle={4} 
                                                dataKey="value" 
                                                stroke="none"
                                                animationBegin={0}
                                                animationDuration={1500}
                                            >
                                                {allocData.map((_, index) => <Cell key={index} fill={ALLOC_COLORS[index % ALLOC_COLORS.length]} />)}
                                            </Pie>
                                            <ReTooltip 
                                                content={<CustomTooltip />}
                                                wrapperStyle={{ outline: 'none' }}
                                            />
                                        </PieChart>
                                    </ResponsiveContainer>
                                </div>
                                
                                {/* Legend matching the user's latest screenshot */}
                                <div className="mt-4 flex flex-wrap justify-center gap-x-6 gap-y-2">
                                    {allocData.map((item, index) => (
                                        <div key={index} className="flex items-center gap-2">
                                            <div className="w-4 h-4 rounded-sm" style={{ backgroundColor: ALLOC_COLORS[index % ALLOC_COLORS.length] }}></div>
                                            <span className="text-[10px] font-tech font-bold text-slate-300 uppercase tracking-wider">{item.name}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ) : (
                            <div className="text-center">
                                <TrendingUp size={64} className="text-slate-800 animate-pulse mx-auto mb-6" />
                                <p className="text-[11px] text-slate-600 font-mono uppercase tracking-[0.3em]">Institutional Simulator Ready</p>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {activeTab === 'BACKTESTER' && (
                <div className="bg-[#0a0a0a] rounded-[2.5rem] p-6 md:p-8 border border-white/5 min-h-[500px] flex flex-col relative overflow-hidden shadow-2xl">
                    <div className="absolute top-0 left-0 w-64 h-64 bg-emerald-500/5 blur-[100px] pointer-events-none"></div>
                    
                    {btStep === 'CHOICE' && (
                        <div className="flex-1 flex flex-col items-center justify-center text-center py-10 animate-in fade-in zoom-in-95 duration-500">
                            <History size={64} className="text-neon-blue mb-6" />
                            <h3 className="text-2xl md:text-3xl font-tech font-bold text-white mb-4 uppercase tracking-widest">Select Architect Mode</h3>
                            <p className="text-slate-500 max-w-lg mb-12 leading-relaxed text-sm">How do you wish to construct your backtest? Let ManiquantAi generate parameters or build manually.</p>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-3xl">
                                <button 
                                    onClick={() => setBtStep('AI_CONFIG')}
                                    className="group p-8 rounded-[2rem] bg-[#0c1321] border border-white/5 hover:border-neon-blue/50 hover:bg-neon-blue/5 transition-all text-left space-y-4"
                                >
                                    <BrainCircuit className="text-neon-blue group-hover:scale-110 transition-transform" size={40} />
                                    <div>
                                        <h4 className="text-xl font-tech font-bold text-white uppercase group-hover:text-neon-blue">AI Quant Architect</h4>
                                        <p className="text-xs text-slate-500 font-light leading-relaxed">AI will generate optimal backtesting parameters based on your risk and goals.</p>
                                    </div>
                                </button>
                                
                                <button 
                                    onClick={() => setBtStep('INPUT')}
                                    className="group p-8 rounded-[2rem] bg-[#0c1321] border border-white/5 hover:border-neon-purple/50 hover:bg-neon-purple/5 transition-all text-left space-y-4"
                                >
                                    <Settings className="text-neon-purple group-hover:scale-110 transition-transform" size={40} />
                                    <div>
                                        <h4 className="text-xl font-tech font-bold text-white uppercase group-hover:text-neon-purple">Manual Builder</h4>
                                        <p className="text-xs text-slate-500 font-light leading-relaxed">Manually input your logic and variables for direct lookback analysis.</p>
                                    </div>
                                </button>
                            </div>
                        </div>
                    )}

                    {btStep === 'AI_CONFIG' && (
                        <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
                            <div className="flex items-center gap-4 border-b border-white/5 pb-6">
                                <button onClick={() => setBtStep('CHOICE')} className="p-2 hover:bg-white/5 rounded-full text-slate-500 hover:text-white transition-colors">
                                    <ArrowLeft size={20} />
                                </button>
                                <h3 className="text-xl font-tech font-bold text-white uppercase tracking-widest flex items-center gap-2">
                                    <Sparkles size={18} className="text-neon-blue" />
                                    AI Strategy Generation
                                </h3>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="space-y-2">
                                    <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest flex items-center gap-1">
                                        <Target size={12} className="text-neon-blue" /> Risk per Trade (%)
                                    </label>
                                    <input 
                                        type="number"
                                        value={aiConstraints.riskPercent} 
                                        onChange={e => setAiConstraints({...aiConstraints, riskPercent: e.target.value})}
                                        className="w-full bg-[#0c1321] border border-slate-800 p-3 rounded-xl text-white outline-none focus:border-neon-blue font-mono" 
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest flex items-center gap-1">
                                        <AlertTriangle size={12} className="text-red-400" /> Max Drawdown (%)
                                    </label>
                                    <input 
                                        type="number"
                                        value={aiConstraints.maxDrawdown} 
                                        onChange={e => setAiConstraints({...aiConstraints, maxDrawdown: e.target.value})}
                                        className="w-full bg-[#0c1321] border border-slate-800 p-3 rounded-xl text-white outline-none focus:border-red-500 font-mono" 
                                    />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest flex items-center gap-1">
                                        <BarChart2 size={12} className="text-neon-green" /> Profit Factor
                                    </label>
                                    <input 
                                        type="number"
                                        step="0.1"
                                        value={aiConstraints.profitFactor} 
                                        onChange={e => setAiConstraints({...aiConstraints, profitFactor: e.target.value})}
                                        className="w-full bg-[#0c1321] border border-slate-800 p-3 rounded-xl text-white outline-none focus:border-neon-green font-mono" 
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
                                <div className="space-y-6">
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Asset Target</label>
                                            <input 
                                                value={assetName} 
                                                onChange={e => setAssetName(e.target.value)}
                                                className="w-full bg-[#0c1321] border border-slate-800 p-4 rounded-xl text-white outline-none focus:border-neon-blue font-tech tracking-wider" 
                                                placeholder="e.g., NIFTY 50"
                                            />
                                        </div>
                                        <div className="space-y-2">
                                            <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest flex items-center gap-1">
                                                <DollarSign size={12} className="text-neon-blue" /> Currency
                                            </label>
                                            <select 
                                                value={btCurrency}
                                                onChange={e => setBtCurrency(e.target.value)}
                                                className="w-full bg-[#0c1321] border border-slate-800 p-4 rounded-xl text-white outline-none focus:border-neon-blue font-mono"
                                            >
                                                {CURRENCIES.map(c => (
                                                    <option key={c.code} value={c.code}>{c.label}</option>
                                                ))}
                                            </select>
                                        </div>
                                    </div>

                                    <div className="space-y-2">
                                        <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Risk Tolerance</label>
                                        <div className="flex gap-2">
                                            {['Low', 'Medium', 'High'].map(r => (
                                                <button 
                                                    key={r}
                                                    onClick={() => setAiConstraints({...aiConstraints, risk: r})}
                                                    className={`flex-1 py-3 rounded-xl border text-xs font-bold transition-all ${aiConstraints.risk === r ? 'bg-neon-blue border-neon-blue text-black' : 'bg-slate-900 border-slate-800 text-slate-500 hover:text-white'}`}
                                                >
                                                    {r}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                <div className="space-y-6">
                                    <div className="space-y-2">
                                        <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Trading Style</label>
                                        <select 
                                            value={aiConstraints.style}
                                            onChange={e => setAiConstraints({...aiConstraints, style: e.target.value})}
                                            className="w-full bg-[#0c1321] border border-slate-800 p-4 rounded-xl text-white outline-none focus:border-neon-blue font-tech"
                                        >
                                            <option>Scalp</option>
                                            <option>Intraday</option>
                                            <option>Swing</option>
                                            <option>Positional</option>
                                        </select>
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Market Outlook</label>
                                        <select 
                                            value={aiConstraints.outlook}
                                            onChange={e => setAiConstraints({...aiConstraints, outlook: e.target.value})}
                                            className="w-full bg-[#0c1321] border border-slate-800 p-4 rounded-xl text-white outline-none focus:border-neon-blue font-tech"
                                        >
                                            <option>Bullish</option>
                                            <option>Bearish</option>
                                            <option>Sideways/Ranging</option>
                                            <option>Volatile</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <button 
                                onClick={handleGenerateAiStrategy}
                                disabled={btLoading}
                                className="w-full py-5 bg-gradient-to-r from-neon-blue to-blue-700 text-white font-bold font-tech text-xl tracking-widest rounded-2xl shadow-lg hover:shadow-neon-blue/20 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
                            >
                                {btLoading ? <RefreshCw className="animate-spin" /> : <Play />}
                                {btLoading ? 'SIMULATING ARCHITECT...' : 'INITIATE AI GENERATION'}
                            </button>
                        </div>
                    )}

                    {btStep === 'INPUT' && (
                        <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
                             <div className="flex items-center gap-4 border-b border-white/5 pb-6">
                                <button onClick={() => setBtStep('CHOICE')} className="p-2 hover:bg-white/5 rounded-full text-slate-500 hover:text-white transition-colors">
                                    <ArrowLeft size={20} />
                                </button>
                                <h3 className="text-xl font-tech font-bold text-white uppercase tracking-widest flex items-center gap-2">
                                    <Terminal size={18} className="text-neon-purple" />
                                    Review Strategy Logic
                                </h3>
                            </div>

                            <div className="space-y-4">
                                <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Logic Description (Generated or Input)</label>
                                <textarea 
                                    value={strategyDesc}
                                    onChange={e => setStrategyDesc(e.target.value)}
                                    className="w-full h-48 bg-[#0c1321]/40 border border-slate-800 rounded-2xl p-6 text-slate-200 font-mono text-sm outline-none focus:border-neon-purple transition-all custom-scrollbar resize-none"
                                    placeholder="Strategy details will appear here..."
                                />
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div className="space-y-2">
                                    <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Test Asset</label>
                                    <input value={assetName} onChange={e => setAssetName(e.target.value)} className="w-full bg-[#0c1321] border border-slate-800 p-3 rounded-xl text-white text-sm" />
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Simulation Duration</label>
                                    <select value={duration} onChange={e => setDuration(e.target.value)} className="w-full bg-[#0c1321] border border-slate-800 p-3 rounded-xl text-white text-sm">
                                        <option>3 Months</option>
                                        <option>6 Months</option>
                                        <option>1 Year</option>
                                        <option>3 Years</option>
                                    </select>
                                </div>
                                <div className="space-y-2">
                                    <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Base Currency</label>
                                    <select 
                                        value={btCurrency}
                                        onChange={e => setBtCurrency(e.target.value)}
                                        className="w-full bg-[#0c1321] border border-slate-800 p-3 rounded-xl text-white text-sm outline-none font-mono"
                                    >
                                        {CURRENCIES.map(c => (
                                            <option key={c.code} value={c.code}>{c.label}</option>
                                        ))}
                                    </select>
                                </div>
                            </div>

                            <button 
                                onClick={handleIdentifyParams}
                                disabled={btLoading || !strategyDesc}
                                className="w-full py-5 bg-neon-purple text-white font-bold font-tech text-xl tracking-widest rounded-2xl shadow-lg hover:bg-neon-purple/80 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
                            >
                                {btLoading ? <RefreshCw className="animate-spin" /> : <ChevronRight />}
                                {btLoading ? 'PROCESSING...' : 'ANALYZE SIMULATION PARAMS'}
                            </button>
                        </div>
                    )}

                    {btStep === 'PARAMS' && (
                        <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
                             <div className="flex items-center gap-4 border-b border-white/5 pb-6">
                                <button onClick={() => setBtStep('INPUT')} className="p-2 hover:bg-white/5 rounded-full text-slate-500 hover:text-white transition-colors">
                                    <ArrowLeft size={20} />
                                </button>
                                <h3 className="text-xl font-tech font-bold text-white uppercase tracking-widest flex items-center gap-2">
                                    <Settings size={18} className="text-neon-green" />
                                    Refine Simulation Variables
                                </h3>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {btParams.map((param) => (
                                    <div key={param.id} className="space-y-2">
                                        <label className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">{param.question}</label>
                                        <input 
                                            value={btParamValues[param.id] || ''} 
                                            onChange={e => setBtParamValues({...btParamValues, [param.id]: e.target.value})}
                                            className="w-full bg-[#0c1321] border border-slate-800 p-4 rounded-xl text-white font-tech tracking-wider outline-none focus:border-neon-green"
                                        />
                                    </div>
                                ))}
                            </div>

                            <button 
                                onClick={handleRunBacktest}
                                disabled={btLoading}
                                className="w-full py-5 bg-gradient-to-r from-emerald-600 to-teal-800 text-white font-bold font-tech text-xl tracking-widest rounded-2xl shadow-lg hover:shadow-emerald-500/20 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
                            >
                                {btLoading ? <RefreshCw className="animate-spin" /> : <Play />}
                                {btLoading ? 'RUNNING LOOKBACK...' : 'EXECUTE SIMULATION'}
                            </button>
                        </div>
                    )}

                    {btStep === 'RESULT' && btResult && (
                        <div className="space-y-8 animate-in slide-in-from-bottom-8 duration-700">
                            {/* Detailed Profitability & Capital Grid */}
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                                {/* Profitability Verdict Card */}
                                <div className="bg-[#0c1321] p-6 rounded-2xl border border-white/5 shadow-xl flex flex-col justify-between h-[120px]">
                                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] mb-2">STATUS</p>
                                    <div className="flex items-center gap-2">
                                        {btResult.verdict === 'PROFITABLE' ? (
                                            <CheckCircle2 className="text-[#0aff68]" size={24} />
                                        ) : btResult.verdict === 'UNPROFITABLE' ? (
                                            <XCircle className="text-[#ef4466]" size={24} />
                                        ) : (
                                            <AlertTriangle className="text-yellow-500" size={24} />
                                        )}
                                        <p className={`text-2xl font-tech font-bold ${btResult.verdict === 'PROFITABLE' ? 'text-[#0aff68]' : btResult.verdict === 'UNPROFITABLE' ? 'text-[#ef4466]' : 'text-yellow-500'}`}>
                                            {btResult.verdict}
                                        </p>
                                    </div>
                                </div>

                                {/* Capital Used */}
                                <div className="bg-[#0c1321] p-6 rounded-2xl border border-white/5 shadow-xl flex flex-col justify-between h-[120px]">
                                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] mb-2">CAPITAL ALLOCATED</p>
                                    <div className="flex items-center gap-2 text-white">
                                        <Wallet size={24} className="text-neon-blue" />
                                        <p className="text-2xl font-tech font-bold">
                                            {getCurrencySymbol(btCurrency)}10,000.00
                                        </p>
                                    </div>
                                </div>

                                {/* Net P/L Amount */}
                                <div className="bg-[#0c1321] p-6 rounded-2xl border border-white/5 shadow-xl flex flex-col justify-between h-[120px]">
                                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] mb-2">
                                        {btResult.metrics.netProfit.startsWith('-') ? 'NET LOSS' : 'NET PROFIT'}
                                    </p>
                                    <p className={`text-2xl font-tech font-bold ${btResult.metrics.netProfit.startsWith('-') ? 'text-[#ef4466]' : 'text-[#0aff68]'}`}>
                                        {btResult.metrics.netProfit}
                                    </p>
                                </div>

                                {/* Max Drawdown */}
                                <div className="bg-[#0c1321] p-6 rounded-2xl border border-white/5 shadow-xl flex flex-col justify-between h-[120px]">
                                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] mb-2">MAX DRAWDOWN</p>
                                    <p className="text-2xl font-tech font-bold text-[#ef4466]">{btResult.metrics.maxDrawdown}</p>
                                </div>
                            </div>

                            {/* Secondary Stats Grid */}
                            <div className="grid grid-cols-3 gap-4">
                                {[
                                    { label: 'Win Rate', value: btResult.metrics.winRate, icon: CheckCircle2, color: 'text-neon-blue' },
                                    { label: 'Profit Factor', value: btResult.metrics.profitFactor, icon: BarChart2, color: 'text-neon-purple' },
                                    { label: 'Total Trades', value: btResult.metrics.totalTrades, icon: MousePointer2, color: 'text-slate-400' },
                                ].map((m, i) => (
                                    <div key={i} className="bg-[#0c1321]/60 p-4 rounded-xl border border-white/5 flex flex-col items-center text-center">
                                        <m.icon size={16} className={`${m.color} mb-2`} />
                                        <p className="text-[8px] text-slate-500 font-bold uppercase tracking-widest mb-1">{m.label}</p>
                                        <p className="text-sm font-tech font-bold text-white">{m.value}</p>
                                    </div>
                                ))}
                            </div>

                            {/* Chart Area with stylized pill header */}
                            <div className="bg-[#0c1321] rounded-[2.5rem] border border-white/5 p-6 md:p-10 relative group shadow-2xl">
                                <div className="absolute top-8 left-8 z-10">
                                    <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-black/60 backdrop-blur-md rounded-full border border-white/10 shadow-lg">
                                        <TrendingUp size={14} className="text-[#0aff68]" />
                                        <span className="text-[10px] font-tech font-bold text-white uppercase tracking-wider">
                                            EQUITY CURVE ({assetName} - {duration})
                                        </span>
                                    </div>
                                </div>
                                
                                <div className="h-[400px] w-full mt-8">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <AreaChart data={btResult.equityCurve}>
                                            <defs>
                                                <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                                                    <stop offset="5%" stopColor="#00f3ff" stopOpacity={0.2}/>
                                                    <stop offset="95%" stopColor="#00f3ff" stopOpacity={0}/>
                                                </linearGradient>
                                            </defs>
                                            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} opacity={0.2} />
                                            <XAxis dataKey="date" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                                            <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                                            <ReTooltip contentStyle={{ backgroundColor: '#05050a', border: '1px solid #1e293b', borderRadius: '12px' }} />
                                            <Area type="monotone" dataKey="equity" stroke="#00f3ff" strokeWidth={3} fillOpacity={1} fill="url(#equityGradient)" />
                                        </AreaChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>

                            {/* AI Analysis Log - Magenta styling from screenshot */}
                            <div className="bg-[#0c1321]/80 rounded-2xl border-l-4 border-l-neon-purple border border-white/5 p-8 space-y-4">
                                <div className="flex items-center gap-3">
                                    <div className="p-1.5 bg-neon-purple/20 rounded-lg">
                                        <BrainCircuit size={18} className="text-neon-purple" />
                                    </div>
                                    <h4 className="text-[10px] font-bold text-neon-purple uppercase tracking-[0.3em]">AI ANALYSIS LOG</h4>
                                </div>
                                <p className="text-slate-400 text-sm leading-relaxed font-light italic">
                                    "{btResult.analysis}"
                                </p>
                            </div>

                            <button 
                                onClick={() => setBtStep('CHOICE')}
                                className="w-full py-4 bg-white/5 hover:bg-white/10 border border-white/5 rounded-2xl text-[10px] font-tech font-bold text-slate-500 hover:text-white tracking-[0.3em] transition-all uppercase"
                            >
                                NEW SIMULATION CYCLE
                            </button>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default Simulator;
