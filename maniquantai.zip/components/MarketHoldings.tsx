
import React, { useMemo } from 'react';
import { Investor, PortfolioItem } from '../types';
import { ShieldCheck, TrendingUp, Users, Search, BarChart3 } from 'lucide-react';

interface MarketHoldingsProps {
  investors: Investor[];
  loading: boolean;
}

interface CompanyAggregated {
  company: string;
  ticker: string;
  sector: string;
  holders: string[];
  maxAllocation: string;
}

const MarketHoldings: React.FC<MarketHoldingsProps> = ({ investors, loading }) => {
  const aggregatedData = useMemo(() => {
    const companies: Record<string, CompanyAggregated> = {};
    
    investors.forEach(investor => {
      // Added optional chaining here to prevent crash if portfolio is missing
      investor.portfolio?.forEach(item => {
        const key = item.ticker || item.company;
        if (!companies[key]) {
          companies[key] = {
            company: item.company,
            ticker: item.ticker,
            sector: item.sector,
            holders: [investor.name],
            maxAllocation: item.allocation
          };
        } else {
          if (!companies[key].holders.includes(investor.name)) {
            companies[key].holders.push(investor.name);
          }
          // Simple comparison for max allocation
          const currentVal = parseFloat(companies[key].maxAllocation);
          const newVal = parseFloat(item.allocation);
          if (newVal > currentVal) {
            companies[key].maxAllocation = item.allocation;
          }
        }
      });
    });

    return Object.values(companies).sort((a, b) => b.holders.length - a.holders.length);
  }, [investors]);

  if (loading) return null;

  return (
    <div className="py-24 relative z-10">
      <div className="flex flex-col items-center mb-16 text-center px-4">
        <div className="inline-flex items-center px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full text-[10px] text-blue-400 font-mono tracking-widest mb-4">
            INSTITUTIONAL RADAR
        </div>
        <h2 className="text-3xl md:text-5xl font-tech font-bold text-white mb-6 tracking-tight">
          MARKET <span className="text-blue-500">HOLDINGS</span> DIRECTORY
        </h2>
        <p className="text-slate-500 max-w-xl text-sm leading-relaxed">
            Discover companies that have captured the interest of multiple legendary investors. High consensus often indicates strong fundamental moats.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {aggregatedData.map((data, idx) => (
            <div key={idx} className="glass-panel group p-6 rounded-2xl border border-white/5 hover:border-blue-500/30 transition-all duration-300 relative overflow-hidden">
               {/* Background visual */}
               <div className="absolute -top-4 -right-4 w-20 h-20 bg-blue-500/5 rounded-full blur-2xl group-hover:bg-blue-500/10 transition-colors"></div>
               
               <div className="relative z-10">
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center text-xs font-bold text-white font-mono">
                      {data.ticker.substring(0, 4)}
                    </div>
                    {data.holders.length > 1 && (
                      <div className="flex items-center gap-1 bg-emerald-500/10 px-2 py-1 rounded-full border border-emerald-500/20">
                         <ShieldCheck size={10} className="text-emerald-500" />
                         <span className="text-[9px] font-bold text-emerald-400 uppercase">High Consensus</span>
                      </div>
                    )}
                  </div>

                  <h4 className="text-lg font-bold text-white truncate mb-1 group-hover:text-blue-400 transition-colors">
                    {data.company}
                  </h4>
                  <p className="text-[10px] text-slate-500 font-mono uppercase tracking-widest mb-4">
                    {data.sector} • {data.ticker}
                  </p>

                  <div className="space-y-3 pt-4 border-t border-white/5">
                    <div className="flex justify-between items-center text-[10px] font-bold">
                       <span className="text-slate-500 uppercase tracking-widest flex items-center gap-1">
                          <Users size={12} className="text-blue-500" /> Legend Affinity
                       </span>
                       <span className="text-white">{data.holders.length} Holders</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {data.holders.map((name, i) => (
                        <div key={i} className="text-[9px] px-2 py-0.5 bg-white/5 rounded text-slate-400 border border-white/5">
                          {name.split(' ').pop()}
                        </div>
                      ))}
                    </div>

                    <div className="flex justify-between items-center text-[10px] font-bold pt-2">
                       <span className="text-slate-500 uppercase tracking-widest flex items-center gap-1">
                          <BarChart3 size={12} className="text-emerald-500" /> Max Portfolio Weight
                       </span>
                       <span className="text-emerald-400 font-tech">{data.maxAllocation}</span>
                    </div>
                  </div>
               </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mt-16 text-center">
         <div className="inline-flex items-center gap-2 px-6 py-3 bg-slate-900/50 border border-white/10 rounded-xl text-xs text-slate-500 font-mono">
            <TrendingUp size={14} className="text-blue-500" />
            AGGREGATING DATA FROM {investors.length} LEGENDARY PORTFOLIOS
         </div>
      </div>
    </div>
  );
};

export default MarketHoldings;
