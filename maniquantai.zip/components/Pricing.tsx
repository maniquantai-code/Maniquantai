
import React from 'react';
import { PlanType } from '../types';
import { PLANS } from '../constants';
import { Check, ShieldCheck } from 'lucide-react';

interface PricingProps {
  currentPlan: PlanType;
  onUpgrade: (plan: PlanType) => void;
  message?: string | null;
}

const Pricing: React.FC<PricingProps> = ({ currentPlan, onUpgrade, message }) => {
  return (
    <div id="pricing" className="py-20 px-4 max-w-7xl mx-auto">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold font-tech text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-purple">
          Neural Uplink Packages
        </h2>
        <p className="text-slate-400 mt-4">Upgrade your trading arsenal with quantum-enhanced capabilities.</p>
      </div>

      {message && (
        <div className="mb-8 max-w-2xl mx-auto p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-xl flex items-center justify-center text-yellow-400 font-bold font-tech tracking-wider animate-in fade-in slide-in-from-top-4">
            {message}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {(Object.keys(PLANS) as PlanType[]).filter(k => k !== PlanType.FREE).map((key) => {
          const plan = PLANS[key];
          const isCurrent = currentPlan === key;

          return (
            <div 
              key={key} 
              className={`relative group p-1 rounded-2xl bg-gradient-to-b ${key === PlanType.ELITE ? 'from-yellow-400 to-orange-600' : 'from-slate-700 to-slate-900'} transition-all duration-300 hover:scale-105`}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-neon-blue to-purple-600 opacity-0 group-hover:opacity-20 blur-xl transition-opacity"></div>
              
              <div className="h-full bg-slate-900 rounded-xl p-8 flex flex-col relative z-10 border border-slate-700">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-2xl font-bold font-tech text-white">{plan.name}</h3>
                  {key === PlanType.ELITE && <ShieldCheck className="text-yellow-400" />}
                </div>
                
                <div className="mb-6">
                  <span className="text-4xl font-bold text-white">₹{plan.price}</span>
                  <span className="text-slate-400">/{plan.period}</span>
                </div>

                <ul className="space-y-4 mb-8 flex-grow">
                  {plan.features.map((feat, idx) => (
                    <li key={idx} className="flex items-start text-sm text-slate-300">
                      <Check size={16} className="mr-2 text-neon-green shrink-0 mt-0.5" />
                      {feat}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => onUpgrade(key)}
                  disabled={isCurrent}
                  className={`w-full py-3 rounded-lg font-bold font-tech tracking-wider transition-all
                    ${isCurrent 
                      ? 'bg-slate-700 text-slate-400 cursor-default' 
                      : 'bg-gradient-to-r from-neon-blue to-blue-600 text-white hover:shadow-[0_0_20px_rgba(0,243,255,0.4)]'
                    }`}
                >
                  {isCurrent ? 'ACTIVE UPLINK' : 'INITIALIZE'}
                </button>
                
                <p className="text-xs text-center mt-3 text-slate-500">
                   {key !== PlanType.FREE && "Includes Auto-Pay (Cancel Anytime)"}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Pricing;
