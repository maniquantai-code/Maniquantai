
import React, { useState, useEffect } from 'react';
import { Cpu, Lock, Mail, User, ArrowRight, Activity, AlertCircle, CheckCircle2 } from 'lucide-react';
import TradingBackground from './TradingBackground';
import { supabase } from '../services/supabaseClient';
import { INITIAL_CREDITS } from '../constants';
import { PlanType } from '../types';

interface AuthPageProps {
  onLogin: () => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const factor = window.innerWidth < 768 ? 0.5 : 1;
      const x = (e.clientX / window.innerWidth - 0.5) * 2 * factor;
      const y = (e.clientY / window.innerHeight - 0.5) * 2 * factor;
      setMousePos({ x, y });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        // Auth state listener in App.tsx will handle the rest
      } else {
        // Sign Up
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              username: username,
              plan: PlanType.FREE,
              credits: INITIAL_CREDITS
            }
          }
        });
        if (error) throw error;

        // Check if email confirmation is required
        if (data.user && !data.session) {
            setSuccessMsg("Account created successfully! Please check your email to confirm registration.");
            setLoading(false);
            return;
        }

        // Only insert profile if we have a valid session (prevents RLS 42501 error)
        if (data.user && data.session) {
          const { error: profileError } = await supabase.from('profiles').upsert([
            {
              id: data.user.id,
              email: email,
              username: username,
              plan: PlanType.FREE,
              credits: INITIAL_CREDITS
            }
          ]);
          
          if (profileError) {
             console.warn("Profile creation deferred:", profileError.message);
          }
        }
      }
      onLogin(); 
    } catch (err: any) {
      // Improved Error Handling
      let msg = err.message || "Authentication failed";
      let isHandled = false;
      
      const lowerMsg = msg.toLowerCase();

      if (lowerMsg.includes("invalid login credentials")) {
        msg = "Invalid email or password. Please try again.";
        isHandled = true;
      } else if (lowerMsg.includes("email not confirmed")) {
        msg = "Please verify your email address before logging in.";
        isHandled = true;
      } else if (lowerMsg.includes("user already registered")) {
        msg = "Account already exists. Redirecting to login...";
        isHandled = true;
        // Auto-switch to login after a brief delay for better UX
        setTimeout(() => {
            setIsLogin(true);
            setError(null);
        }, 1500);
      }
      
      // Log unexpected errors
      if (!isHandled) {
          console.error("Auth error:", err);
      }
      
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#020405] flex items-center justify-center p-4 relative overflow-hidden font-sans selection:bg-emerald-900 selection:text-white perspective-[1000px]">
      <TradingBackground />

      <div 
        className="bg-[#0a0a0a]/80 backdrop-blur-xl p-6 md:p-12 rounded-2xl w-full max-w-[400px] border border-slate-800 relative z-10 shadow-2xl transition-all duration-300"
        style={{
            transform: `translate(${mousePos.x * -5}px, ${mousePos.y * -5}px) rotateX(${mousePos.y * 0.5}deg) rotateY(${mousePos.x * 0.5}deg)`,
            transformStyle: 'preserve-3d'
        }}
      >
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center p-4 mb-4 bg-slate-900/80 rounded-full border border-slate-800 shadow-xl relative group">
             <div className="absolute inset-0 bg-emerald-500/20 blur-xl rounded-full"></div>
             <Cpu className="text-emerald-500 relative z-10 group-hover:animate-pulse" size={32} />
          </div>
          
          <h1 className="text-3xl md:text-4xl font-tech font-bold tracking-tight text-white mb-2">
            Maniquant<span className="text-emerald-500">Ai</span>
          </h1>
          
          <p className="text-[10px] text-slate-500 uppercase tracking-[0.2em] font-mono font-bold">
             Neural Trading Terminal Access
          </p>
        </div>

        <div className="flex border-b border-slate-800 mb-6">
            <button
                type="button"
                onClick={() => { setIsLogin(true); setError(null); setSuccessMsg(null); }}
                className={`flex-1 py-2 text-[10px] font-bold tracking-widest transition-all ${isLogin ? 'text-white border-b-2 border-emerald-500' : 'text-slate-600'}`}
            >
                LOGIN
            </button>
            <button
                type="button"
                onClick={() => { setIsLogin(false); setError(null); setSuccessMsg(null); }}
                className={`flex-1 py-2 text-[10px] font-bold tracking-widest transition-all ${!isLogin ? 'text-white border-b-2 border-emerald-500' : 'text-slate-600'}`}
            >
                REGISTER
            </button>
        </div>

        {error && (
            <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg flex items-start gap-2 animate-in fade-in slide-in-from-top-2">
                <AlertCircle size={14} className="text-red-500 mt-0.5 shrink-0" />
                <p className="text-xs text-red-400 font-mono leading-tight">{error}</p>
            </div>
        )}

        {successMsg && (
            <div className="mb-4 p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg flex items-start gap-2 animate-in fade-in slide-in-from-top-2">
                <CheckCircle2 size={14} className="text-emerald-500 mt-0.5 shrink-0" />
                <p className="text-xs text-emerald-400 font-mono leading-tight">{successMsg}</p>
            </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div className="space-y-1">
              <label className="text-[8px] text-slate-600 font-mono uppercase tracking-widest">Identity</label>
              <input type="text" required value={username} onChange={(e) => setUsername(e.target.value)} className="w-full bg-slate-900/50 border border-slate-800 text-white rounded-lg py-3 px-4 focus:border-emerald-500 outline-none transition-all placeholder:text-slate-800 text-xs" placeholder="USERNAME" />
            </div>
          )}

          <div className="space-y-1">
            <label className="text-[8px] text-slate-600 font-mono uppercase tracking-widest">Email</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-slate-900/50 border border-slate-800 text-white rounded-lg py-3 px-4 focus:border-emerald-500 outline-none transition-all placeholder:text-slate-800 text-xs" placeholder="QUANT@FIRM.COM" />
          </div>

          <div className="space-y-1">
            <label className="text-[8px] text-slate-600 font-mono uppercase tracking-widest">Secret Key</label>
            <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="w-full bg-slate-900/50 border border-slate-800 text-white rounded-lg py-3 px-4 focus:border-emerald-500 outline-none transition-all placeholder:text-slate-800 text-xs" placeholder="••••••••••••" />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-white text-black font-bold text-xs py-4 rounded-lg hover:bg-slate-200 transition-all flex items-center justify-center mt-6 tracking-widest active:scale-95 shadow-xl disabled:opacity-50"
          >
            {loading ? <Activity className="animate-spin mr-2" size={14} /> : <ArrowRight className="mr-2" size={14} />}
            {loading ? (isLogin ? 'AUTHENTICATING...' : 'INITIALIZING...') : (isLogin ? 'ESTABLISH LINK' : 'CREATE NEURAL ID')}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AuthPage;
