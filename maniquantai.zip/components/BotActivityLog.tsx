import React, { useState, useEffect, useRef } from 'react';
import { Terminal, Activity } from 'lucide-react';

interface LogEntry {
  id: number;
  timestamp: string;
  type: 'INFO' | 'SUCCESS' | 'WARNING' | 'ERROR' | 'TRADE';
  message: string;
}

const ASSETS = ['BTC/USD', 'ETH/USD', 'XAU/USD', 'EUR/USD', 'NIFTY 50', 'BANKNIFTY'];
const ACTIONS = [
  'Scanning market patterns...',
  'Analyzing liquidity zones...',
  'Calculating RSI divergence...',
  'Volume spike detected.',
  'Checking correlation matrix...',
  'Adjusting trailing stop...',
  'Sentiment analysis: BULLISH',
  'Sentiment analysis: BEARISH',
];

const BotActivityLog: React.FC = () => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  const addLog = () => {
    const now = new Date();
    const timeString = now.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }) + `.${now.getMilliseconds().toString().slice(0,2)}`;
    
    const randomAsset = ASSETS[Math.floor(Math.random() * ASSETS.length)];
    const rand = Math.random();
    
    let type: LogEntry['type'] = 'INFO';
    let message = '';

    if (rand > 0.9) {
      type = 'TRADE';
      const side = Math.random() > 0.5 ? 'LONG' : 'SHORT';
      message = `EXECUTING ${side} ORDER: ${randomAsset} @ MARKET | Conf: ${(85 + Math.random() * 14).toFixed(1)}%`;
    } else if (rand > 0.7) {
      type = 'SUCCESS';
      message = `Signal Verified: ${randomAsset} - Pattern Match ${(90 + Math.random() * 9).toFixed(1)}%`;
    } else if (rand < 0.1) {
      type = 'WARNING';
      message = `High Volatility Detected: ${randomAsset} - Widening spreads`;
    } else {
      type = 'INFO';
      message = `${ACTIONS[Math.floor(Math.random() * ACTIONS.length)]} [${randomAsset}]`;
    }

    const newLog: LogEntry = {
      id: Date.now(),
      timestamp: timeString,
      type,
      message
    };

    setLogs(prev => [...prev.slice(-14), newLog]); // Keep last 15 logs
  };

  useEffect(() => {
    // Initial logs
    setLogs([
      { id: 1, timestamp: 'SYSTEM', type: 'INFO', message: 'Neural Network Initialized.' },
      { id: 2, timestamp: 'SYSTEM', type: 'INFO', message: 'Connected to Exchange Feeds.' },
      { id: 3, timestamp: 'SYSTEM', type: 'SUCCESS', message: 'Deep Learning Models Loaded.' },
    ]);

    const interval = setInterval(() => {
      addLog();
    }, 2500); // Add log every 2.5 seconds

    return () => clearInterval(interval);
  }, []);

  // Auto scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const getColor = (type: LogEntry['type']) => {
    switch (type) {
      case 'SUCCESS': return 'text-neon-green';
      case 'TRADE': return 'text-neon-purple font-bold';
      case 'WARNING': return 'text-yellow-400';
      case 'ERROR': return 'text-red-500';
      default: return 'text-slate-400';
    }
  };

  return (
    <div className="bg-slate-950 rounded-xl border border-slate-800 p-4 font-mono text-xs md:text-sm h-full flex flex-col shadow-inner shadow-black/50">
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-2 mb-2">
        <Terminal size={14} className="text-neon-blue" />
        <span className="text-slate-300 font-bold">LIVE EXECUTION TERMINAL</span>
        <Activity size={12} className="text-neon-green animate-pulse ml-auto" />
      </div>
      
      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-1.5 scroll-smooth pr-2">
        {logs.map((log) => (
          <div key={log.id} className="flex space-x-3 hover:bg-white/5 p-0.5 rounded transition-colors">
            <span className="text-slate-600 shrink-0 select-none">[{log.timestamp}]</span>
            <span className={`${getColor(log.type)} break-all`}>
              {log.type === 'TRADE' && <span className="mr-2 text-xs bg-neon-purple text-white px-1 rounded">EXEC</span>}
              {log.message}
            </span>
          </div>
        ))}
        <div className="animate-pulse text-neon-blue">_</div>
      </div>
    </div>
  );
};

export default BotActivityLog;
