import React from 'react';
import { UserState } from '../types';
import { Wallet, Cpu, LogOut, LogIn } from 'lucide-react';

interface NavbarProps {
    user: UserState;
    isAuthenticated: boolean;
    onLogout: () => void;
    onLogin?: () => void;
    onOpenPricing?: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, isAuthenticated, onLogout, onLogin, onOpenPricing }) => {
    return (
        <nav className="flex justify-between items-center w-full px-4 md:px-8 py-5 border-b border-white/5 bg-black/40 backdrop-blur-xl sticky top-0 z-40 transition-all">
            <div className="flex items-center space-x-3 group cursor-pointer">
                <div className="relative">
                    <div className="absolute inset-0 bg-emerald-500 blur-lg opacity-40 group-hover:opacity-60 transition-opacity"></div>
                    <Cpu className="text-emerald-500 relative z-10 drop-shadow-[0_0_8px_rgba(16,185,129,0.8)]" size={32} />
                </div>
                <h1 className="text-2xl md:text-3xl font-tech font-bold tracking-tighter text-white">
                    MANI<span className="text-emerald-500 drop-shadow-[0_0_10px_rgba(16,185,129,0.6)]">QUANT</span><span className="text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.4)]">Ai</span>
                </h1>
            </div>
            
            <div className="flex items-center space-x-3 md:space-x-6">
                {isAuthenticated && (
                    <button 
                        onClick={onOpenPricing}
                        className="flex items-center bg-slate-900/60 px-3 py-2 md:px-4 rounded-full border border-slate-700 shadow-inner hover:bg-slate-800 hover:border-emerald-500/50 transition-all cursor-pointer group/credits"
                        title="View Plans"
                    >
                        <Wallet size={16} className="text-emerald-500 mr-2 group-hover/credits:scale-110 transition-transform" />
                        <span className="font-mono text-emerald-400 font-bold tracking-wider text-sm md:text-base">{user.credits > 1000 ? '∞' : user.credits}</span>
                        <span className="ml-2 text-[10px] md:text-xs text-slate-500 font-bold group-hover/credits:text-slate-300 hidden sm:inline">CREDITS</span>
                    </button>
                )}
                
                {isAuthenticated ? (
                    <button 
                        onClick={onLogout}
                        className="flex items-center bg-white/5 text-slate-300 px-3 py-2 md:px-5 rounded-lg font-bold font-tech border border-white/10 hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/30 transition-all duration-300 group tracking-wide text-sm md:text-base"
                    >
                        <LogOut size={16} className="mr-0 md:mr-2 group-hover:-translate-x-1 transition-transform" />
                        <span className="hidden md:inline">DISCONNECT</span>
                    </button>
                ) : (
                    <button 
                        onClick={onLogin}
                        className="flex items-center bg-emerald-600 text-white px-4 py-2 rounded-lg font-bold font-tech hover:bg-emerald-500 hover:shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all duration-300 tracking-wide text-sm md:text-base"
                    >
                        <LogIn size={16} className="mr-2" />
                        ACCESS <span className="hidden md:inline ml-1">TERMINAL</span>
                    </button>
                )}
            </div>
        </nav>
    );
};

export default Navbar;