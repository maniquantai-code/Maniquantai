import React from 'react';
import { Download, Terminal, Code2, Cpu } from 'lucide-react';
import { BOT_SOURCE_CODE } from '../constants/botSource';

const BotDownload: React.FC = () => {
  const handleDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([BOT_SOURCE_CODE], {type: 'text/x-python'});
    element.href = URL.createObjectURL(file);
    element.download = "maniquant_crypto_bot.py";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="glass-panel p-8 rounded-2xl w-full max-w-4xl mx-auto my-8 border border-slate-700 relative overflow-hidden group">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-neon-purple/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
      
      <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
        <div className="space-y-4 flex-1">
          <div className="flex items-center space-x-3 mb-2">
            <div className="p-2 bg-slate-900 rounded-lg border border-slate-700">
                <Terminal className="text-neon-purple" size={24} />
            </div>
            <h2 className="text-2xl font-tech font-bold text-white">
                ManiQuantAi <span className="text-neon-purple">Bot v1.0</span>
            </h2>
          </div>
          
          <p className="text-slate-400 text-sm leading-relaxed">
              Acquire our advanced open-source algorithmic trading engine. 
              Engineered with <span className="text-slate-200 font-bold">XGBoost & LSTM</span> neural networks 
              for high-precision trend prediction on MetaTrader 5.
          </p>

          <div className="flex flex-wrap gap-2 pt-2">
             <div className="flex items-center space-x-1 px-3 py-1 rounded-full bg-slate-900/80 border border-slate-700 text-xs text-slate-300">
                 <Cpu size={12} className="text-neon-blue" />
                 <span>TensorFlow/Keras</span>
             </div>
             <div className="flex items-center space-x-1 px-3 py-1 rounded-full bg-slate-900/80 border border-slate-700 text-xs text-slate-300">
                 <Code2 size={12} className="text-neon-green" />
                 <span>Python 3.10+</span>
             </div>
             <div className="flex items-center space-x-1 px-3 py-1 rounded-full bg-slate-900/80 border border-slate-700 text-xs text-slate-300">
                 <span className="w-2 h-2 rounded-full bg-yellow-500"></span>
                 <span>MetaTrader 5</span>
             </div>
          </div>
        </div>
        
        <button 
          onClick={handleDownload}
          className="w-full md:w-auto px-8 py-4 bg-gradient-to-r from-neon-purple to-purple-800 text-white rounded-xl font-bold font-tech flex items-center justify-center gap-3 hover:scale-105 transition-all shadow-[0_0_25px_rgba(188,19,254,0.3)] hover:shadow-[0_0_40px_rgba(188,19,254,0.5)] border border-purple-500/30"
        >
          <Download size={24} />
          <span>DOWNLOAD SOURCE</span>
        </button>
      </div>
    </div>
  );
};

export default BotDownload;