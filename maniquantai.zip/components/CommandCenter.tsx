
import React from 'react';
import { 
  TrendingUp, 
  Activity, 
  ShieldCheck, 
  Zap, 
  ArrowUpRight, 
  ArrowDownRight,
  BarChart3,
  Cpu,
  BrainCircuit
} from 'lucide-react';
import { UserState, StockTicker } from '../types';
import { MOCK_TICKERS } from '../constants';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface CommandCenterProps {
  user: UserState;
  onNavigate: (tab: string) => void;
}

const mockChartData = [
  { name: '00:00', value: 4000 },
  { name: '04:00', value: 3000 },
  { name: '08:00', value: 5000 },
  { name: '12:00', value: 4500 },
  { name: '16:00', value: 6000 },
  { name: '20:00', value: 5500 },
  { name: '23:59', value: 7000 },
];

const CommandCenter: React.FC<CommandCenterProps> = ({ user, onNavigate }) => {
  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      {/* Welcome Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h2 className="text-4xl font-tech font-bold text-white tracking-tight">
            Terminal <span className="text-emerald-500">Command Center</span>
          </h2>
          <p className="text-slate-500 font-mono text-xs uppercase tracking-[0.3em] mt-2">
            Status: System Operational • Neural Link Active
          </p>
        </div>
        <div className="flex gap-4">
          <div className="px-4 py-2 bg-slate-900 border border-white/5 rounded-xl flex items-center gap-3">
             <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
             <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest font-mono">12ms Latency</span>
          </div>
        </div>
      </div>

      {/* Top Level Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Active Automations', value: '3 Bots', icon: BrainCircuit, color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
          { label: 'Neural Precision', value: '94.2%', icon: Cpu, color: 'text-neon-blue', bg: 'bg-neon-blue/10' },
          { label: 'Market Sentiment', value: 'Bullish', icon: Activity, color: 'text-neon-green', bg: 'bg-neon-green/10' },
          { label: 'Security Status', value: 'Encrypted', icon: ShieldCheck, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
        ].map((stat, i) => (
          <div key={i} className="glass-panel p-6 rounded-2xl border border-white/5 group hover:border-white/20 transition-all">
            <div className={`w-10 h-10 ${stat.bg} ${stat.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
              <stat.icon size={20} />
            </div>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{stat.label}</p>
            <p className="text-2xl font-tech font-bold text-white mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
        {/* Performance Chart */}
        <div className="xl:col-span-8 glass-panel p-8 rounded-3xl border border-white/5 min-h-[450px] flex flex-col">
           <div className="flex justify-between items-center mb-8">
              <h3 className="text-sm font-bold text-white uppercase tracking-widest flex items-center gap-3">
                <BarChart3 size={18} className="text-emerald-500" />
                Aggregated Yield Velocity
              </h3>
              <div className="flex gap-2">
                {['1D', '1W', '1M'].map(t => (
                  <button key={t} className={`px-3 py-1 rounded-lg text-[10px] font-bold font-mono transition-all ${t === '1D' ? 'bg-emerald-500 text-black' : 'text-slate-500 hover:text-white'}`}>{t}</button>
                ))}
              </div>
           </div>
           
           <div className="flex-grow">
              <ResponsiveContainer width="100%" height="100%">
                 <AreaChart data={mockChartData}>
                    <defs>
                      <linearGradient id="yieldGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} opacity={0.3} />
                    <XAxis dataKey="name" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} dy={10} />
                    <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} dx={-10} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#05050a', border: '1px solid #1e293b', borderRadius: '12px' }}
                      itemStyle={{ color: '#10b981', fontFamily: 'Rajdhani' }}
                    />
                    <Area type="monotone" dataKey="value" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#yieldGradient)" />
                 </AreaChart>
              </ResponsiveContainer>
           </div>
        </div>

        {/* Live Feed Snapshot */}
        <div className="xl:col-span-4 space-y-6">
           <div className="glass-panel p-6 rounded-3xl border border-white/5 h-full flex flex-col">
              <h3 className="text-sm font-bold text-white uppercase tracking-widest mb-6 flex items-center gap-3">
                <Zap size={18} className="text-yellow-400" />
                Pulse Stream
              </h3>
              <div className="space-y-4 flex-grow overflow-y-auto pr-2 custom-scrollbar">
                {MOCK_TICKERS.slice(0, 5).map((ticker, i) => (
                  <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-transparent hover:border-white/10 transition-all cursor-pointer group">
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center font-tech font-bold text-xs ${ticker.isPositive ? 'text-emerald-500' : 'text-red-500'}`}>
                        {ticker.symbol.substring(0, 2)}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-white group-hover:text-emerald-400 transition-colors">{ticker.symbol}</p>
                        <p className="text-[10px] text-slate-500 font-mono tracking-widest">{ticker.price}</p>
                      </div>
                    </div>
                    <div className={`flex items-center gap-1 text-[10px] font-bold font-mono ${ticker.isPositive ? 'text-emerald-500' : 'text-red-500'}`}>
                      {ticker.isPositive ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                      {ticker.change}%
                    </div>
                  </div>
                ))}
              </div>
              <button 
                onClick={() => onNavigate('intelligence')}
                className="mt-6 w-full py-4 bg-slate-900 text-slate-400 rounded-2xl font-tech font-bold text-xs tracking-widest hover:text-white hover:bg-slate-800 transition-all uppercase"
              >
                Deep Intelligence Feed
              </button>
           </div>
        </div>
      </div>
      
      {/* Quick Launch Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <button 
            onClick={() => onNavigate('vision')}
            className="group p-8 bg-gradient-to-br from-neon-green/10 to-transparent border border-neon-green/20 rounded-[2.5rem] hover:scale-[1.02] transition-all text-left space-y-4"
          >
             <Cpu size={32} className="text-neon-green" />
             <div>
                <h4 className="text-xl font-tech font-bold text-white uppercase">Vision Engine</h4>
                <p className="text-xs text-slate-500 leading-relaxed font-light">Execute institutional-grade neural chart recognition and trade level identification.</p>
             </div>
          </button>
          <button 
            onClick={() => onNavigate('simulator')}
            className="group p-8 bg-gradient-to-br from-neon-purple/10 to-transparent border border-neon-purple/20 rounded-[2.5rem] hover:scale-[1.02] transition-all text-left space-y-4"
          >
             <History size={32} className="text-neon-purple" />
             <div>
                <h4 className="text-xl font-tech font-bold text-white uppercase">Quantum Backtest</h4>
                <p className="text-xs text-slate-500 leading-relaxed font-light">Simulate complex strategy logic across 5+ years of historical data in 4 dimensions.</p>
             </div>
          </button>
          <button 
            onClick={() => onNavigate('bots')}
            className="group p-8 bg-gradient-to-br from-yellow-400/10 to-transparent border border-yellow-400/20 rounded-[2.5rem] hover:scale-[1.02] transition-all text-left space-y-4"
          >
             <BrainCircuit size={32} className="text-yellow-400" />
             <div>
                <h4 className="text-xl font-tech font-bold text-white uppercase">Neural Bots</h4>
                <p className="text-xs text-slate-500 leading-relaxed font-light">Deploy and monitor autonomous trading agents via MT5 neural bridges.</p>
             </div>
          </button>
      </div>
    </div>
  );
};

export default CommandCenter;
