
import React from 'react';
import { MOCK_TICKERS } from '../constants';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';

const Marquee: React.FC = () => {
  return (
    <div className="w-full bg-[#05050a] border-b border-emerald-500/10 overflow-hidden py-2 backdrop-blur-md sticky top-0 z-[100] h-12 md:h-14 flex items-center">
      <div className="flex animate-marquee whitespace-nowrap">
        {[...MOCK_TICKERS, ...MOCK_TICKERS].map((ticker, index) => (
          <div key={index} className="mx-6 md:mx-10 flex items-center space-x-3 md:space-x-4 group">
            <div className={`p-1 md:p-1.5 rounded bg-slate-900 border border-white/5`}>
              {ticker.isPositive ? <ArrowUpRight size={14} className="text-emerald-500" /> : <ArrowDownRight size={14} className="text-red-500" />}
            </div>
            <span className="font-tech font-bold text-slate-200 tracking-wider text-xs md:text-sm uppercase">{ticker.symbol}</span>
            <span className="text-white font-mono text-xs md:text-sm">{ticker.price}</span>
            <span className={`text-[10px] md:text-xs font-bold font-mono px-2 py-0.5 rounded-sm ${ticker.isPositive ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'}`}>
              {ticker.isPositive ? '+' : ''}{ticker.change}%
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Marquee;
