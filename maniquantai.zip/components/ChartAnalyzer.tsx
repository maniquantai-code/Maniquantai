
import React, { useState, useRef } from 'react';
import { Upload, Cpu, Activity, FileText, Settings, BrainCircuit, Target, Shield, Sparkles, X, Layers, TrendingUp, AlertCircle, Info, ChevronRight } from 'lucide-react';
import { analyzeChartImage, getDeepChartAnalysis } from '../services/geminiService';
import { AnalysisResult, DeepAnalysisResult } from '../types';

interface ChartAnalyzerProps {
  hasCredits: boolean;
  consumeCredit: () => void;
  openPricing: (reason?: string) => void;
}

const CHART_TYPES = ['Candlestick', 'Line', 'Area', 'Heikin Ashi', 'Renko'];

const ChartAnalyzer: React.FC<ChartAnalyzerProps> = ({ hasCredits, consumeCredit, openPricing }) => {
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [deepLoading, setDeepLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [deepResult, setDeepResult] = useState<DeepAnalysisResult | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [chartType, setChartType] = useState('Candlestick');
  const [showDeepModal, setShowDeepModal] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setResult(null); 
        setDeepResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyze = async () => {
    if (!image) return;
    if (!hasCredits) {
        openPricing("Please upgrade your plan");
        return;
    }
    setLoading(true);
    try {
      const analysis = await analyzeChartImage(image, { 
        chartType, 
        focusIndicators: ['RSI', 'MACD']
      });
      setResult(analysis);
      consumeCredit();
    } catch (err) {
      alert("Analysis failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleDeepAnalysis = async () => {
    if (!image || !result) return;
    if (!hasCredits) {
        openPricing("Please upgrade your plan");
        return;
    }
    setDeepLoading(true);
    try {
      const deep = await getDeepChartAnalysis(image, result);
      setDeepResult(deep);
      setShowDeepModal(true);
      consumeCredit();
    } catch (err) {
      alert("Deep analysis failed.");
    } finally {
      setDeepLoading(false);
    }
  };

  return (
    <div className="glass-panel rounded-2xl md:rounded-[2.5rem] p-4 md:p-8 w-full max-w-5xl mx-auto border border-white/10 relative overflow-hidden">
      {/* Visual background accents */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-neon-blue/5 blur-[80px] pointer-events-none"></div>
      
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 md:mb-8 gap-4">
        <div className="flex items-center gap-3 md:gap-4">
          <div className="w-10 h-10 md:w-12 md:h-12 bg-neon-blue/10 rounded-lg md:rounded-xl flex items-center justify-center border border-neon-blue/20">
            <Cpu className="text-neon-blue" size={20} />
          </div>
          <div>
            <h2 className="text-xl md:text-2xl font-tech font-bold text-white uppercase tracking-tight leading-none">Vision Engine</h2>
            <p className="text-[10px] text-slate-500 font-mono tracking-widest uppercase mt-1">Neural Analysis Terminal</p>
          </div>
        </div>
        
        <div className="flex gap-2 w-full sm:w-auto">
           <button 
            onClick={() => setShowSettings(!showSettings)}
            className="flex-1 sm:flex-none p-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-400 hover:text-white flex justify-center transition-colors"
           >
             <Settings size={18} />
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
        <div className="space-y-4 md:space-y-6">
          <div 
            onClick={() => fileInputRef.current?.click()}
            className={`relative h-48 md:h-64 border-2 border-dashed rounded-2xl md:rounded-3xl transition-all cursor-pointer flex flex-col items-center justify-center overflow-hidden
              ${image ? 'border-neon-blue/50 bg-neon-blue/5' : 'border-slate-800 bg-slate-950/50 hover:border-slate-700'}`}
          >
            {image ? (
              <img src={image} alt="Chart" className="w-full h-full object-contain p-2" />
            ) : (
              <>
                <Upload className="text-slate-600 mb-2 md:mb-4 animate-bounce" size={32} />
                <p className="text-xs text-slate-400 font-tech tracking-widest uppercase">Select Chart Image</p>
              </>
            )}
            <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
          </div>

          {showSettings && (
            <div className="bg-slate-900/50 p-4 rounded-xl border border-white/5 space-y-4 animate-in fade-in slide-in-from-top-4">
              <div className="space-y-1">
                <p className="text-[9px] text-slate-600 font-bold uppercase tracking-widest">Chart Type Selection</p>
                <select value={chartType} onChange={(e) => setChartType(e.target.value)} className="w-full bg-slate-950 border border-slate-800 p-3 rounded-lg text-xs text-white outline-none">
                  {CHART_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
          )}

          <button 
            onClick={handleAnalyze}
            disabled={!image || loading}
            className={`w-full py-4 md:py-5 rounded-xl md:rounded-2xl font-bold font-tech text-lg md:text-xl tracking-widest transition-all flex items-center justify-center gap-3
              ${!image || loading 
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
                : 'bg-gradient-to-r from-neon-blue to-blue-700 text-white shadow-[0_0_20px_rgba(0,243,255,0.15)] hover:shadow-neon-blue/40'}`}
          >
            {loading ? <BrainCircuit className="animate-spin" size={20} /> : <Activity size={20} />}
            {loading ? 'PROCESSING...' : 'INITIATE SCAN'}
          </button>
        </div>

        <div className="space-y-4 md:space-y-6">
          {result ? (
            <div className="h-full flex flex-col space-y-4 animate-in fade-in slide-in-from-right-4 duration-500">
              <div className="bg-slate-900/40 rounded-2xl md:rounded-3xl border border-white/5 overflow-hidden">
                 <div className="bg-white/5 p-4 md:p-6 border-b border-white/5 flex justify-between items-center">
                    <span className="text-[10px] md:text-xs font-bold text-slate-300 uppercase tracking-widest">Trend: {result.trend || 'DETECTED'}</span>
                    <span className="text-xs md:text-sm font-tech font-bold text-emerald-400">{result.confidence}% Conf.</span>
                 </div>

                 <div className="p-4 md:p-6 space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-black/40 p-3 rounded-xl border border-white/5">
                        <p className="text-[8px] text-slate-500 uppercase font-bold tracking-widest mb-1 flex items-center gap-1"><Shield size={8} /> Stop Loss</p>
                        <p className="text-[11px] md:text-xs font-mono font-bold text-red-500">{result.stopLoss}</p>
                      </div>
                      <div className="bg-black/40 p-3 rounded-xl border border-white/5">
                        <p className="text-[8px] text-slate-500 uppercase font-bold tracking-widest mb-1 flex items-center gap-1"><Target size={8} /> Take Profit</p>
                        <p className="text-[11px] md:text-xs font-mono font-bold text-emerald-500">{result.takeProfit}</p>
                      </div>
                    </div>

                    <div className="bg-black/40 p-4 rounded-xl border border-white/5">
                      <p className="text-[9px] text-slate-500 uppercase font-bold tracking-widest mb-2">Primary Logic</p>
                      <p className="text-[10px] md:text-xs text-slate-400 leading-relaxed italic line-clamp-3">"{result.reasoning}"</p>
                    </div>
                 </div>
              </div>

              {/* New Deep Analysis Trigger */}
              <button
                onClick={handleDeepAnalysis}
                disabled={deepLoading}
                className="w-full py-4 bg-gradient-to-r from-pink-600 to-purple-800 text-white rounded-xl md:rounded-2xl font-tech font-bold tracking-[0.2em] uppercase text-sm flex items-center justify-center gap-3 shadow-lg shadow-purple-500/20 hover:scale-[1.02] transition-all disabled:opacity-50"
              >
                {deepLoading ? <RefreshIcon className="animate-spin" /> : <Sparkles size={18} className="text-yellow-400" />}
                {deepLoading ? 'GENERATING NEURAL DEEP DIVE...' : 'GENERATE INSTITUTIONAL DEEP DIVE'}
              </button>
            </div>
          ) : (
            <div className="h-full min-h-[250px] bg-slate-950/30 rounded-2xl border border-dashed border-slate-800 flex flex-col items-center justify-center p-6 md:p-12 text-center">
               <Activity size={32} className="text-slate-800 mb-4 opacity-30" />
               <p className="text-[10px] md:text-xs text-slate-600 font-mono uppercase tracking-widest">Vision Engine Standby</p>
            </div>
          )}
        </div>
      </div>

      {/* Institutional Deep Dive Modal */}
      {showDeepModal && deepResult && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/95 backdrop-blur-3xl animate-in fade-in duration-500" onClick={() => setShowDeepModal(false)}></div>
          
          <div className="relative z-10 w-full max-w-4xl bg-[#05050a] border border-white/10 rounded-[2.5rem] shadow-2xl overflow-hidden animate-in zoom-in-95 slide-in-from-bottom-8 duration-500 flex flex-col max-h-[90vh]">
            {/* Header */}
            <div className="p-8 border-b border-white/5 flex justify-between items-center bg-gradient-to-r from-pink-500/5 to-transparent">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-pink-500/20 rounded-2xl border border-pink-500/40">
                  <Sparkles className="text-pink-400" size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-tech font-bold text-white uppercase tracking-wider">Institutional Deep Dive</h3>
                  <p className="text-[10px] font-mono text-pink-500 uppercase tracking-widest">Neural Pro Architect v2.1</p>
                </div>
              </div>
              <button onClick={() => setShowDeepModal(false)} className="p-3 bg-white/5 hover:bg-white/10 rounded-full text-slate-500 hover:text-white transition-all">
                <X size={20} />
              </button>
            </div>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto p-8 md:p-10 space-y-10 custom-scrollbar">
               {/* Market Structure Section */}
               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                     <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest border-l-2 border-pink-500 pl-3">
                        <Layers size={14} className="text-pink-500" /> Market Micro-Structure
                     </div>
                     <p className="text-sm text-slate-300 leading-relaxed bg-white/5 p-5 rounded-2xl border border-white/5 italic">
                        "{deepResult.marketStructure}"
                     </p>
                  </div>

                  <div className="space-y-4">
                     <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest border-l-2 border-emerald-500 pl-3">
                        <TrendingUp size={14} className="text-emerald-500" /> Institutional Bias
                     </div>
                     <p className="text-sm text-slate-300 leading-relaxed bg-white/5 p-5 rounded-2xl border border-white/5 italic">
                        "{deepResult.institutionalBias}"
                     </p>
                  </div>
               </div>

               {/* Risk Matrix & Liquidity */}
               <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2 space-y-4">
                     <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest border-l-2 border-blue-500 pl-3">
                        <Target size={14} className="text-blue-500" /> Strategic Risk Matrix
                     </div>
                     <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        {deepResult.riskMatrix.map((item, i) => (
                           <div key={i} className="bg-[#0c1321] p-4 rounded-xl border border-white/5 hover:border-blue-500/30 transition-all group">
                              <p className="text-[9px] text-blue-400 font-bold uppercase mb-1">{item.tier}</p>
                              <p className="text-sm font-mono font-bold text-white mb-2">{item.target}</p>
                              <div className="flex justify-between items-center text-[10px] text-slate-500">
                                 <span>R:R</span>
                                 <span className="text-blue-500 font-bold">{item.rrRatio}</span>
                              </div>
                           </div>
                        ))}
                     </div>
                  </div>

                  <div className="space-y-4">
                     <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest border-l-2 border-yellow-500 pl-3">
                        <Activity size={14} className="text-yellow-500" /> Liquidity Zones
                     </div>
                     <div className="space-y-2">
                        {deepResult.liquidityZones.map((zone, i) => (
                           <div key={i} className="flex items-center gap-3 p-3 bg-white/5 rounded-xl border border-white/5">
                              <div className="w-1.5 h-1.5 rounded-full bg-yellow-500"></div>
                              <span className="text-xs font-mono text-slate-400">{zone}</span>
                           </div>
                        ))}
                     </div>
                  </div>
               </div>

               {/* Invalidation & Macro */}
               <div className="bg-red-500/5 border border-red-500/10 p-6 rounded-[2rem] space-y-4">
                  <div className="flex items-center gap-3">
                    <AlertCircle size={18} className="text-red-500" />
                    <h4 className="text-xs font-bold text-red-500 uppercase tracking-widest">Thesis Invalidation Criteria</h4>
                  </div>
                  <p className="text-sm text-slate-400 leading-relaxed font-light">
                    {deepResult.invalidationCriteria}
                  </p>
               </div>

               {deepResult.macroContext && (
                  <div className="bg-blue-500/5 border border-blue-500/10 p-6 rounded-[2rem] space-y-4">
                    <div className="flex items-center gap-3">
                      <Info size={18} className="text-blue-400" />
                      <h4 className="text-xs font-bold text-blue-400 uppercase tracking-widest">Macro Context Inference</h4>
                    </div>
                    <p className="text-sm text-slate-400 leading-relaxed font-light">
                      {deepResult.macroContext}
                    </p>
                  </div>
               )}
            </div>

            {/* Footer */}
            <div className="p-8 border-t border-white/5 bg-black flex justify-between items-center">
               <div className="flex gap-4">
                  <button className="flex items-center gap-2 px-5 py-2.5 bg-slate-900 border border-white/5 rounded-xl text-xs font-bold text-slate-400 hover:text-white transition-all">
                    <FileText size={14} /> EXPORT PDF
                  </button>
               </div>
               <button 
                  onClick={() => setShowDeepModal(false)}
                  className="px-8 py-2.5 bg-white text-black font-tech font-bold rounded-xl hover:bg-slate-200 transition-all uppercase text-sm tracking-wider"
                >
                  Terminate Interface
                </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const RefreshIcon = ({ className }: { className?: string }) => (
  <svg className={className} width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/>
    <path d="M21 3v5h-5"/>
  </svg>
);

export default ChartAnalyzer;
