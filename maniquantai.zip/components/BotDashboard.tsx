import React, { useState } from 'react';
import { PlanType } from '../types';
import { BOT_NAME } from '../constants';
import { Power, Settings, TrendingUp, Check, Key, Download, Cpu, Code2, Terminal, Wallet, Activity, AlertTriangle, ArrowRight } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import ConnectExchangeModal from './ConnectExchangeModal';
import BotActivityLog from './BotActivityLog';
import { BOT_SOURCE_CODE } from '../constants/botSource';

interface BotDashboardProps {
  plan: PlanType;
  isBotConnected: boolean;
  onConnect: (exchange: string, user: string, pass: string) => void;
  toggleBot: () => void;
  connectedExchanges: string[];
}

const pnlData = [
  { time: '10:00', value: 0 },
  { time: '10:30', value: 120 },
  { time: '11:00', value: 80 },
  { time: '11:30', value: 240 },
  { time: '12:00', value: 390 },
  { time: '12:30', value: 350 },
  { time: '13:00', value: 510 },
  { time: '13:30', value: 680 },
  { time: '14:00', value: 720 },
  { time: '14:30', value: 690 },
  { time: '15:00', value: 840 },
  { time: '15:30', value: 950 },
  { time: '16:00', value: 1240 },
];

const BotDashboard: React.FC<BotDashboardProps> = ({ plan, isBotConnected, onConnect, toggleBot, connectedExchanges = [] }) => {
  const [selectedExchange, setSelectedExchange] = useState('MT5');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleOpenModal = (ex: string) => {
    setSelectedExchange(ex);
    setIsModalOpen(true);
  };

  const handleDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([BOT_SOURCE_CODE], {type: 'text/x-python'});
    element.href = URL.createObjectURL(file);
    element.download = "maniquant_crypto_bot.py";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="glass-panel p-6 lg:p-8 rounded-3xl border border-neon-green/20 overflow-hidden relative group transition-all duration-500 hover:shadow-[0_0_50px_rgba(10,255,104,0.1)]">
      {/* Dynamic Backgrounds */}
      <div className="absolute -top-32 -right-32 w-96 h-96 bg-neon-green/10 rounded-full blur-[100px] pointer-events-none animate-pulse-slow"></div>
      <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-neon-purple/10 rounded-full blur-[100px] pointer-events-none animate-pulse-slow" style={{animationDelay: '2s'}}></div>

      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 relative z-10 border-b border-white/5 pb-6">
        <div className="flex items-center space-x-5 mb-4 md:mb-0">
            <div className="relative">
                <div className={`w-4 h-4 rounded-full ${isBotConnected ? 'bg-neon-green shadow-[0_0_15px_#0aff68]' : 'bg-slate-500'} absolute top-0 left-0 ${isBotConnected ? 'animate-ping opacity-75' : ''}`}></div>
                <div className={`w-4 h-4 rounded-full ${isBotConnected ? 'bg-neon-green' : 'bg-slate-500'} relative z-10 border-2 border-black`}></div>
            </div>
            <div>
                <h2 className="text-4xl font-tech font-bold text-white tracking-wider flex items-center">
                    {BOT_NAME} 
                    <span className="ml-3 text-sm px-2 py-0.5 rounded bg-gradient-to-r from-neon-purple/20 to-blue-500/20 border border-neon-purple/50 text-neon-purple font-mono">v1.0 BETA</span>
                </h2>
                <div className="flex items-center text-xs text-slate-400 font-mono mt-1 space-x-3">
                     <span className="flex items-center"><Activity size={10} className="mr-1" /> STATUS: {isBotConnected ? 'ONLINE' : 'STANDBY'}</span>
                     {isBotConnected && <span className="text-neon-green flex items-center"><Check size={10} className="mr-1" /> SYSTEM OPTIMAL</span>}
                </div>
            </div>
        </div>
        
        {isBotConnected && (
             <button 
                onClick={toggleBot}
                className="group relative px-6 py-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/50 rounded-xl overflow-hidden transition-all shadow-lg shadow-red-500/5"
            >
                <div className="absolute inset-0 bg-red-500/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                <span className="relative flex items-center font-bold font-tech tracking-wider">
                    <Power size={18} className="mr-2" /> DISENGAGE SYSTEM
                </span>
            </button>
        )}
      </div>

      {/* Main Content Area */}
      {!isBotConnected ? (
        // OFFLINE / DOWNLOAD STATE
        <div className="flex flex-col xl:flex-row items-center gap-12 py-4 relative z-10">
            {/* Left: Info & Features */}
            <div className="flex-1 space-y-8">
                <div>
                    <div className="inline-flex items-center px-3 py-1 rounded-full bg-neon-green/10 border border-neon-green/30 text-neon-green text-xs font-bold tracking-widest mb-4">
                        <Cpu size={12} className="mr-2" /> NEURAL TRADING ENGINE
                    </div>
                    <p className="text-slate-300 text-lg md:text-xl leading-relaxed font-light max-w-2xl">
                        Initialize the <span className="text-white font-bold">ManiQuantAi Autonomous Agent</span>. 
                        Architected with <span className="text-neon-green border-b border-neon-green/50">XGBoost</span> & 
                        <span className="text-neon-blue border-b border-neon-blue/50 mx-1">LSTM</span> networks, 
                        this system identifies micro-trends and executes trades with institutional-grade precision on MetaTrader 5.
                    </p>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {[
                        { label: 'TensorFlow Core', icon: Cpu, color: 'text-neon-blue' },
                        { label: 'Auto-Risk Mgmt', icon: AlertTriangle, color: 'text-yellow-500' },
                        { label: 'Pattern Recog.', icon: Activity, color: 'text-neon-purple' },
                        { label: '0ms Latency', icon: Code2, color: 'text-white' },
                        { label: 'MT5 Bridge', icon: Terminal, color: 'text-neon-green' },
                        { label: 'Sentiment AI', icon: TrendingUp, color: 'text-pink-500' }
                    ].map((feat, i) => (
                         <div key={i} className="flex items-center space-x-3 bg-slate-900/60 p-3 rounded-lg border border-white/5 backdrop-blur-sm hover:border-white/10 transition-colors">
                             <feat.icon size={16} className={feat.color} />
                             <span className="text-xs font-bold text-slate-300">{feat.label}</span>
                         </div>
                    ))}
                </div>
            </div>

            {/* Right: Actions */}
            <div className="flex flex-col w-full xl:w-auto gap-4 min-w-[300px]">
                 <button 
                    onClick={handleDownload}
                    className="w-full py-5 bg-gradient-to-r from-neon-purple to-purple-900 text-white rounded-xl font-bold font-tech text-xl flex items-center justify-center gap-3 hover:scale-[1.02] transition-all shadow-[0_0_40px_rgba(188,19,254,0.3)] hover:shadow-[0_0_60px_rgba(188,19,254,0.5)] border border-purple-500/30 relative overflow-hidden group"
                >
                    <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                    <Download size={24} className="relative z-10" />
                    <span className="relative z-10">DOWNLOAD SOURCE</span>
                </button>
                
                <div className="flex items-center justify-center gap-2 text-[10px] text-slate-500 font-mono tracking-widest uppercase">
                    <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                    VERIFIED SECURE • SHA-256
                </div>

                 <button 
                    onClick={() => handleOpenModal('MT5')}
                    className="w-full py-5 bg-slate-800 hover:bg-slate-750 text-white rounded-xl font-bold font-tech text-xl flex items-center justify-center gap-3 transition-all border border-slate-600 hover:border-neon-green/50 hover:text-neon-green group"
                >
                    <Key size={24} className="group-hover:rotate-12 transition-transform" />
                    CONNECT TERMINAL
                </button>
            </div>
        </div>
      ) : (
        // ONLINE DASHBOARD STATE
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 relative z-10">
            {/* LEFT COLUMN: Charts & Metrics (8 cols) */}
            <div className="xl:col-span-8 space-y-6">
                {/* Metrics Row */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {[
                        { label: 'Total Profit', value: '$1,240.50', sub: '+12.4%', subColor: 'text-neon-green', icon: Wallet, color: 'text-neon-green' },
                        { label: 'Win Rate', value: '68.4%', sub: '124 Trades', subColor: 'text-slate-400', icon: Activity, color: 'text-neon-blue' },
                        { label: 'Risk Exposure', value: '2.1%', sub: 'Moderate', subColor: 'text-yellow-500', icon: AlertTriangle, color: 'text-yellow-500' }
                    ].map((stat, i) => (
                        <div key={i} className="bg-slate-900/60 p-5 rounded-2xl border border-white/5 relative overflow-hidden group hover:border-white/10 transition-colors">
                            <div className="absolute -right-4 -top-4 p-4 opacity-5 group-hover:opacity-10 transition-opacity transform group-hover:scale-110 duration-500">
                                <stat.icon size={80} className={stat.color} />
                            </div>
                            <p className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-2">{stat.label}</p>
                            <p className="text-3xl font-mono font-bold text-white mb-1">{stat.value}</p>
                            <span className={`text-xs font-bold px-2 py-0.5 rounded bg-white/5 ${stat.subColor}`}>{stat.sub}</span>
                        </div>
                    ))}
                </div>

                {/* Main Chart Area */}
                <div className="bg-slate-900/40 p-6 rounded-2xl border border-white/5 h-[400px] relative">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-sm font-bold text-slate-300 flex items-center tracking-wider">
                            <TrendingUp size={16} className="text-neon-green mr-2" /> 
                            REAL-TIME PERFORMANCE (PnL)
                        </h3>
                        <div className="flex bg-slate-900 rounded-lg p-1 border border-white/5">
                            {['1H', '4H', '1D', '1W'].map(t => (
                                <button key={t} className={`text-[10px] px-3 py-1.5 rounded-md font-bold transition-all ${t === '1D' ? 'bg-neon-green text-black shadow-lg shadow-neon-green/20' : 'text-slate-500 hover:text-white'}`}>{t}</button>
                            ))}
                        </div>
                    </div>
                    <ResponsiveContainer width="100%" height="85%">
                        <AreaChart data={pnlData}>
                            <defs>
                                <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#0aff68" stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor="#0aff68" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                            <XAxis dataKey="time" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} dy={10} />
                            <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(val) => `$${val}`} dx={-10} />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '8px', boxShadow: '0 4px 20px rgba(0,0,0,0.5)' }}
                                itemStyle={{ color: '#0aff68', fontFamily: 'monospace' }}
                                labelStyle={{ color: '#94a3b8', marginBottom: '0.5rem', fontSize: '10px', textTransform: 'uppercase' }}
                            />
                            <Area type="monotone" dataKey="value" stroke="#0aff68" strokeWidth={2} fillOpacity={1} fill="url(#colorValue)" />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* RIGHT COLUMN: Feed & Logs (4 cols) */}
            <div className="xl:col-span-4 flex flex-col space-y-6">
                {/* Active Trades */}
                <div className="bg-slate-900/60 rounded-2xl border border-white/5 overflow-hidden flex-1 flex flex-col min-h-[250px]">
                    <div className="p-4 bg-white/5 border-b border-white/5 flex justify-between items-center">
                        <span className="text-xs font-bold text-slate-300 flex items-center"><Activity size={12} className="mr-2 text-neon-purple"/> ACTIVE POSITIONS</span>
                        <span className="text-[10px] bg-neon-green/10 border border-neon-green/30 text-neon-green px-2 py-0.5 rounded font-mono">3 OPEN</span>
                    </div>
                    <div className="p-4 space-y-3">
                        <div className="flex justify-between items-center bg-black/40 p-3 rounded-xl border-l-2 border-neon-green group hover:bg-white/5 transition-colors cursor-pointer">
                            <div className="flex items-center space-x-3">
                                <div className="w-8 h-8 rounded bg-slate-800 flex items-center justify-center text-[10px] font-bold text-white">BTC</div>
                                <div>
                                    <div className="text-xs font-bold text-white flex items-center">BTC/USD <span className="text-[9px] ml-2 px-1 rounded bg-green-500/20 text-green-400">LONG</span></div>
                                    <div className="text-[10px] text-slate-500 font-mono">Entry: 64,230.50</div>
                                </div>
                            </div>
                            <div className="text-right">
                                <div className="text-xs font-bold text-neon-green font-mono">+$450.20</div>
                                <div className="text-[10px] text-neon-green/70">+1.2%</div>
                            </div>
                        </div>

                        <div className="flex justify-between items-center bg-black/40 p-3 rounded-xl border-l-2 border-red-500 group hover:bg-white/5 transition-colors cursor-pointer">
                            <div className="flex items-center space-x-3">
                                <div className="w-8 h-8 rounded bg-slate-800 flex items-center justify-center text-[10px] font-bold text-white">ETH</div>
                                <div>
                                    <div className="text-xs font-bold text-white flex items-center">ETH/USD <span className="text-[9px] ml-2 px-1 rounded bg-red-500/20 text-red-400">SHORT</span></div>
                                    <div className="text-[10px] text-slate-500 font-mono">Entry: 3,450.00</div>
                                </div>
                            </div>
                            <div className="text-right">
                                <div className="text-xs font-bold text-red-500 font-mono">-$24.50</div>
                                <div className="text-[10px] text-red-500/70">-0.1%</div>
                            </div>
                        </div>

                        <div className="flex justify-between items-center bg-black/40 p-3 rounded-xl border-l-2 border-neon-green group hover:bg-white/5 transition-colors cursor-pointer">
                            <div className="flex items-center space-x-3">
                                <div className="w-8 h-8 rounded bg-slate-800 flex items-center justify-center text-[10px] font-bold text-white">XAU</div>
                                <div>
                                    <div className="text-xs font-bold text-white flex items-center">XAU/USD <span className="text-[9px] ml-2 px-1 rounded bg-green-500/20 text-green-400">LONG</span></div>
                                    <div className="text-[10px] text-slate-500 font-mono">Entry: 2,340.10</div>
                                </div>
                            </div>
                            <div className="text-right">
                                <div className="text-xs font-bold text-neon-green font-mono">+$112.80</div>
                                <div className="text-[10px] text-neon-green/70">+0.8%</div>
                            </div>
                        </div>
                    </div>
                    <div className="mt-auto p-3 border-t border-white/5 text-center">
                         <button className="text-[10px] text-slate-400 hover:text-white flex items-center justify-center w-full uppercase tracking-wider font-bold">
                            View All History <ArrowRight size={10} className="ml-1" />
                         </button>
                    </div>
                </div>

                {/* Live Terminal Log */}
                <div className="h-[280px] flex flex-col">
                    <BotActivityLog />
                </div>
            </div>
        </div>
      )}

      <ConnectExchangeModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onConnect={onConnect}
        defaultExchange={selectedExchange}
      />
    </div>
  );
};

export default BotDashboard;