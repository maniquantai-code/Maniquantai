import React, { useEffect, useRef, useMemo } from 'react';

const TRADING_TERMS = [
  "LIQUIDITY", "HEDGE", "ALPHA", "VOLATILITY", "DERIVATIVES", 
  "ARBITRAGE", "QUANT", "YIELD", "LEVERAGE", "EXECUTION",
  "SENTIMENT", "MOMENTUM", "BLOCKCHAIN", "SMART CONTRACT", "RISK"
];

const TradingBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: Array<{x: number, y: number, z: number, speed: number, opacity: number}> = [];

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const initParticles = () => {
      particles = [];
      const count = window.innerWidth < 768 ? 60 : 150;
      for (let i = 0; i < count; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          z: Math.random() * 2 + 1, // Depth factor
          speed: Math.random() * 0.5 + 0.2,
          opacity: Math.random() * 0.4 + 0.1
        });
      }
    };

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Horizon Line Gradient
      const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
      gradient.addColorStop(0, '#020405');
      gradient.addColorStop(0.4, '#050a0a');
      gradient.addColorStop(1, '#020405');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw particles simulating data on a floor
      particles.forEach(p => {
        // Move particles towards the viewer or upwards
        p.y -= p.speed; 
        
        // Reset if off screen
        if (p.y < 0) {
            p.y = canvas.height;
            p.x = Math.random() * canvas.width;
        }

        const depthScale = p.z;
        const size = Math.max(0.5, 2 / depthScale); 
        
        ctx.beginPath();
        // Emerald/Teal color for mature trading look
        ctx.fillStyle = `rgba(16, 185, 129, ${p.opacity})`; 
        ctx.arc(p.x, p.y, size, 0, Math.PI * 2);
        ctx.fill();
        
        // Vertical data lines (like a matrix rain but subtle and rising)
        if (Math.random() > 0.98) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(16, 185, 129, ${p.opacity * 0.5})`;
            ctx.lineWidth = 0.5;
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p.x, p.y + 20);
            ctx.stroke();
        }
      });

      animationFrameId = requestAnimationFrame(draw);
    };

    window.addEventListener('resize', () => {
        resizeCanvas();
        initParticles();
    });
    
    resizeCanvas();
    initParticles();
    draw();

    return () => {
        window.removeEventListener('resize', resizeCanvas);
        cancelAnimationFrame(animationFrameId);
    };
  }, []);

  const terms = useMemo(() => {
    return Array.from({ length: 15 }).map((_, i) => ({
      id: i,
      text: TRADING_TERMS[i % TRADING_TERMS.length],
      left: Math.random() * 90 + 5,
      top: Math.random() * 80 + 10,
      scale: Math.random() * 0.5 + 0.5,
      duration: Math.random() * 20 + 20,
      delay: Math.random() * 10,
    }));
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden bg-[#020405]">
        <style>{`
            @keyframes floorMove {
                0% { background-position: 0% 0%; }
                100% { background-position: 0% 100%; }
            }
            @keyframes floatText {
                0% { transform: translateY(100vh) scale(var(--scale)); opacity: 0; }
                20% { opacity: var(--opacity); }
                80% { opacity: var(--opacity); }
                100% { transform: translateY(-20vh) scale(var(--scale)); opacity: 0; }
            }
            @keyframes chartPulse {
                0% { stroke-dashoffset: 1000; opacity: 0.1; }
                50% { opacity: 0.3; }
                100% { stroke-dashoffset: 0; opacity: 0.1; }
            }
            .trading-floor {
                position: absolute;
                bottom: 0;
                left: -50%;
                width: 200%;
                height: 100vh;
                background-image: 
                    linear-gradient(rgba(16, 185, 129, 0.1) 1px, transparent 1px),
                    linear-gradient(90deg, rgba(16, 185, 129, 0.1) 1px, transparent 1px);
                background-size: 80px 80px;
                transform: perspective(500px) rotateX(60deg);
                animation: floorMove 10s linear infinite;
                mask-image: linear-gradient(to top, rgba(0,0,0,1) 0%, transparent 60%);
                opacity: 0.3;
            }
        `}</style>

        {/* 1. 3D Perspective Grid Floor */}
        <div className="trading-floor"></div>

        {/* 2. Canvas Particles (Rising Data) */}
        <canvas ref={canvasRef} className="absolute inset-0" />

        {/* 3. Background Chart Lines */}
        <div className="absolute inset-0 opacity-20">
             <svg className="w-full h-full" preserveAspectRatio="none">
                 <path d="M0,800 Q400,600 800,900 T1600,700 T2400,500" fill="none" stroke="#10b981" strokeWidth="1" style={{strokeDasharray: 1000, animation: 'chartPulse 15s linear infinite'}} />
                 <path d="M0,600 Q300,800 600,500 T1200,600 T1800,400" fill="none" stroke="#3b82f6" strokeWidth="1" style={{strokeDasharray: 1000, animation: 'chartPulse 20s linear infinite reverse'}} />
             </svg>
        </div>

        {/* 4. Floating Terms */}
        {terms.map((t) => (
            <div
                key={t.id}
                className="absolute font-tech font-bold text-white/5 whitespace-nowrap select-none"
                style={{
                    left: `${t.left}%`,
                    fontSize: `${t.scale * 3}rem`,
                    animation: `floatText ${t.duration}s linear infinite`,
                    animationDelay: `-${t.delay}s`,
                    '--scale': t.scale,
                    '--opacity': t.scale * 0.1
                } as React.CSSProperties}
            >
                {t.text}
            </div>
        ))}
    </div>
  );
};

export default TradingBackground;