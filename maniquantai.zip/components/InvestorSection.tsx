
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { Investor } from '../types';
import { Quote, X, ChevronLeft, ChevronRight, Briefcase, Info, Sparkles, PieChart, Landmark, Globe, ArrowUpRight, Target, Layers, TrendingUp } from 'lucide-react';

interface InvestorCardProps {
  investor: Investor;
  isActive: boolean;
  onClick: () => void;
  onViewMore: () => void;
}

const InvestorCard: React.FC<InvestorCardProps> = ({ investor, isActive, onClick, onViewMore }) => (
    <div 
        onClick={onClick}
        className={`snap-center shrink-0 w-[300px] md:w-[380px] transition-all duration-500 ease-out cursor-pointer relative py-8
          ${isActive ? 'scale-100 opacity-100 z-20' : 'scale-90 opacity-40 blur-[1px] grayscale-[0.8] z-10 hover:opacity-60'}`}
    >
      <div className={`w-full h-[550px] bg-slate-950/80 backdrop-blur-xl rounded-[2.5rem] border transition-all duration-500 overflow-hidden flex flex-col relative group
        ${isActive ? 'border-emerald-500/40 shadow-[0_0_50px_rgba(16,185,129,0.15)]' : 'border-white/5 shadow-none'}`}>
        
        {/* Active Glow Effect */}
        {isActive && (
          <div className="absolute -top-32 -right-32 w-64 h-64 bg-emerald-500/10 rounded-full blur-[80px] pointer-events-none"></div>
        )}
        
        <div className="relative z-10 flex flex-col h-full p-8">
            {/* Header */}
            <div className="flex justify-between items-start mb-6">
                <div className={`p-3 rounded-2xl border transition-colors ${isActive ? 'bg-emerald-500/20 border-emerald-500/30' : 'bg-slate-900 border-white/5'}`}>
                    {investor.location === 'INDIAN' ? <Landmark className={isActive ? 'text-emerald-400' : 'text-slate-500'} size={20} /> : <Globe className={isActive ? 'text-emerald-400' : 'text-slate-500'} size={20} />}
                </div>
                <div className="text-right">
                    <span className="text-[9px] font-mono text-emerald-500/70 uppercase tracking-[0.2em] block mb-1">ROI Index</span>
                    <span className={`text-xl font-tech font-bold ${isActive ? 'text-emerald-400' : 'text-slate-400'}`}>{investor.roi}</span>
                </div>
            </div>

            {/* Name & Title */}
            <div className="mb-4">
              <h3 className={`text-3xl font-tech font-bold tracking-tight transition-colors leading-none mb-2 ${isActive ? 'text-white' : 'text-slate-500'}`}>
                  {investor.name}
              </h3>
              <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest flex items-center gap-2">
                  <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-emerald-500 animate-pulse' : 'bg-slate-700'}`}></span>
                  {investor.platform}
              </p>
            </div>

            {/* Strategy Tag */}
            <div className={`inline-flex items-center px-3 py-1 rounded-lg border w-fit mb-6 ${isActive ? 'bg-white/5 border-white/10 text-slate-300' : 'bg-black/20 border-transparent text-slate-600'}`}>
                <Target size={12} className="mr-2" />
                <span className="text-[10px] font-bold uppercase tracking-wider">{investor.strategy}</span>
            </div>

            {/* Philosophy Quote */}
            <div className="relative flex-grow">
                <Quote className={`absolute -top-2 -left-2 ${isActive ? 'text-emerald-500/20' : 'text-white/5'}`} size={32} />
                <p className={`text-sm leading-relaxed italic pl-6 pt-2 transition-colors line-clamp-4 ${isActive ? 'text-slate-400' : 'text-slate-600'}`}>
                    "{investor.philosophy}"
                </p>
            </div>

            {/* Actions */}
            <div className="mt-auto space-y-3">
                <div className="h-px w-full bg-gradient-to-r from-transparent via-white/10 to-transparent mb-4"></div>
                
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onViewMore();
                  }}
                  className={`w-full py-4 rounded-xl font-tech font-bold text-sm tracking-widest uppercase flex items-center justify-center gap-2 transition-all duration-300
                    ${isActive 
                        ? 'bg-white text-black hover:bg-emerald-400 hover:shadow-[0_0_20px_rgba(16,185,129,0.4)]' 
                        : 'bg-white/5 text-slate-500 hover:bg-white/10 hover:text-slate-300'}`}
                >
                   {isActive ? 'ACCESS DOSSIER' : 'SELECT TITAN'}
                   {isActive && <ArrowUpRight size={16} />}
                </button>
            </div>
        </div>
      </div>
    </div>
  );

interface InvestorSectionProps {
  investors: Investor[];
  loading: boolean;
  isLocked?: boolean;
  onUnlock?: () => void;
}

const InvestorSection: React.FC<InvestorSectionProps> = ({ investors, loading, isLocked = false, onUnlock }) => {
  const [selectedInvestor, setSelectedInvestor] = useState<Investor | null>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  // Calculate sector distribution for the modal
  const sectorData = useMemo(() => {
    if (!selectedInvestor || !selectedInvestor.portfolio) return [];
    
    const sectors: Record<string, number> = {};
    let total = 0;

    selectedInvestor.portfolio.forEach(item => {
        const val = parseFloat(item.allocation);
        if (!isNaN(val)) {
            sectors[item.sector] = (sectors[item.sector] || 0) + val;
            total += val;
        }
    });

    // Normalize or just show distribution logic
    return Object.entries(sectors)
        .map(([name, value]) => ({ name, value }))
        .sort((a, b) => b.value - a.value);
  }, [selectedInvestor]);

  const handleScroll = () => {
    if (!scrollRef.current) return;
    const container = scrollRef.current;
    
    // Find the center point of the container
    const containerCenter = container.scrollLeft + container.offsetWidth / 2;

    let closestIndex = 0;
    let minDistance = Infinity;

    // Find which card is closest to the center
    cardRefs.current.forEach((card, idx) => {
      if (card) {
        const cardCenter = card.offsetLeft + card.offsetWidth / 2;
        const distance = Math.abs(containerCenter - cardCenter);
        if (distance < minDistance) {
          minDistance = distance;
          closestIndex = idx;
        }
      }
    });

    if (closestIndex !== activeIndex) {
      setActiveIndex(closestIndex);
    }
  };

  useEffect(() => {
    const el = scrollRef.current;
    if (el) {
      el.addEventListener('scroll', handleScroll);
      // Center initial card
      scrollToCard(0);
      return () => el.removeEventListener('scroll', handleScroll);
    }
  }, [investors.length]);

  const scrollToCard = (index: number) => {
    const card = cardRefs.current[index];
    if (card && scrollRef.current) {
      card.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'center'
      });
    }
  };

  const handleCardClick = (index: number) => {
    if (activeIndex === index) {
       // Only perform action if already active, otherwise scroll to it
    } else {
      scrollToCard(index);
    }
  };

  return (
    <div className="py-20 relative z-10 overflow-hidden">
      {/* Section Header */}
      <div className="flex flex-col items-center mb-12 text-center px-4 relative z-10">
        <div className="inline-flex items-center px-4 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-[10px] text-emerald-400 font-mono tracking-[0.3em] mb-4">
            LEGENDARY ARCHIVE v3.0
        </div>
        <h2 className="text-4xl md:text-5xl font-tech font-bold text-white mb-6 tracking-tight">
          THE <span className="text-emerald-500">TITAN</span> NETWORK
        </h2>
        <p className="text-slate-500 max-w-2xl text-base leading-relaxed font-light">
            Decipher the strategies and core philosophies of Global & Indian legendary investors.
        </p>
      </div>

      {/* Carousel Controls */}
      {!isLocked && !loading && (
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center mb-4 relative z-20">
            <div className="flex items-center gap-4">
              <span className="text-[10px] font-mono text-slate-600 uppercase tracking-widest">
                Profile {String(activeIndex + 1).padStart(2, '0')} / {String(investors.length).padStart(2, '0')}
              </span>
            </div>
            
            <div className="flex gap-2">
                <button 
                    onClick={() => scrollToCard(Math.max(0, activeIndex - 1))}
                    disabled={activeIndex === 0}
                    className="p-3 bg-slate-900 border border-white/5 rounded-xl text-slate-400 hover:text-emerald-400 hover:border-emerald-500/30 disabled:opacity-20 transition-all"
                >
                    <ChevronLeft size={20} />
                </button>
                <button 
                    onClick={() => scrollToCard(Math.min(investors.length - 1, activeIndex + 1))}
                    disabled={activeIndex === investors.length - 1}
                    className="p-3 bg-slate-900 border border-white/5 rounded-xl text-slate-400 hover:text-emerald-400 hover:border-emerald-500/30 disabled:opacity-20 transition-all"
                >
                    <ChevronRight size={20} />
                </button>
            </div>
        </div>
      )}

      {/* 3D Carousel Container */}
      <div className="relative w-full">
        {loading ? (
            <div className="max-w-7xl mx-auto px-4 flex justify-center gap-8 overflow-hidden">
                {[1, 2, 3].map(i => (
                    <div key={i} className="h-[500px] w-[350px] shrink-0 rounded-[2.5rem] bg-slate-900/50 animate-pulse border border-white/5"></div>
                ))}
            </div>
        ) : (
            <div 
                ref={scrollRef}
                className="flex gap-4 md:gap-8 overflow-x-auto snap-x snap-mandatory px-[50vw] md:px-[calc(50vw-190px)] no-scrollbar py-8 scroll-smooth"
                style={{ scrollBehavior: 'smooth' }}
            >
                {/* Spacer to center first item */}
                <div className="shrink-0 w-[calc(50vw-150px)] md:w-0"></div> 

                {investors.map((investor, idx) => (
                    <div 
                      key={idx} 
                      ref={el => cardRefs.current[idx] = el}
                      className="snap-center shrink-0"
                    >
                      <InvestorCard 
                        investor={investor} 
                        isActive={idx === activeIndex} 
                        onClick={() => handleCardClick(idx)} 
                        onViewMore={() => setSelectedInvestor(investor)}
                      />
                    </div>
                ))}

                {/* Spacer to center last item */}
                <div className="shrink-0 w-[calc(50vw-150px)] md:w-0"></div>
            </div>
        )}
        
        {/* Carousel Fade Edges */}
        <div className="absolute inset-y-0 left-0 w-12 md:w-32 bg-gradient-to-r from-[#020405] to-transparent pointer-events-none z-20"></div>
        <div className="absolute inset-y-0 right-0 w-12 md:w-32 bg-gradient-to-l from-[#020405] to-transparent pointer-events-none z-20"></div>
      </div>

      {/* Modal - Rendered via Portal to avoid z-index/clipping issues */}
      {selectedInvestor && createPortal(
        <div className="fixed inset-0 z-[9999] flex items-end md:items-center justify-center p-0 md:p-4 font-sans">
            {/* Backdrop */}
            <div 
              className="absolute inset-0 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300" 
              onClick={() => setSelectedInvestor(null)}
            ></div>
            
            {/* Modal Card */}
            <div className="relative z-[10000] w-full md:max-w-7xl bg-[#05050a] border border-white/10 rounded-t-[2.5rem] md:rounded-[3rem] shadow-2xl flex flex-col max-h-[95vh] md:max-h-[90vh] animate-in slide-in-from-bottom-10 duration-500 overflow-hidden">
                
                {/* Modal Header */}
                <div className="p-6 md:p-8 border-b border-white/5 flex justify-between items-center bg-gradient-to-r from-emerald-500/5 to-transparent shrink-0">
                    <div className="flex items-center gap-4 md:gap-6">
                        <div className="w-12 h-12 md:w-16 md:h-16 rounded-2xl bg-slate-900 border border-emerald-500/30 flex items-center justify-center shadow-[0_0_30px_rgba(16,185,129,0.1)]">
                             {selectedInvestor.location === 'INDIAN' ? <Landmark className="text-emerald-500" size={24} /> : <Globe className="text-emerald-500" size={24} />}
                        </div>
                        <div>
                            <span className="text-[9px] font-mono text-emerald-500 uppercase tracking-[0.2em] md:tracking-[0.4em] block mb-1">CONFIDENTIAL DOSSIER</span>
                            <h3 className="text-2xl md:text-4xl font-tech font-bold text-white tracking-tight leading-none">{selectedInvestor.name}</h3>
                            <p className="text-slate-500 font-mono text-[10px] md:text-xs uppercase tracking-widest mt-1 truncate max-w-[200px] md:max-w-none">{selectedInvestor.platform}</p>
                        </div>
                    </div>
                    <button 
                        onClick={() => setSelectedInvestor(null)}
                        className="p-3 bg-white/5 hover:bg-white/10 rounded-full text-slate-500 hover:text-white transition-all border border-white/5"
                    >
                        <X size={20} />
                    </button>
                </div>

                {/* Modal Content - Scrollable */}
                <div className="p-6 md:p-10 overflow-y-auto custom-scrollbar flex-1 bg-[#020405]">
                    {/* Grid Layout: Stacks on Tablet (lg), Side-by-Side on Desktop (xl) */}
                    <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 md:gap-12">
                        
                        {/* Left Column: Strategy & Philosophy */}
                        <div className="xl:col-span-2 space-y-8 md:space-y-10">
                            {/* Philosophy */}
                            <div className="bg-slate-900/40 p-6 md:p-10 rounded-3xl border border-white/5 relative group">
                                <Quote className="absolute top-6 right-6 text-emerald-500/10 group-hover:text-emerald-500/20 transition-colors" size={64} />
                                <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                                    <Sparkles size={14} className="text-emerald-500" /> Core Philosophy
                                </h4>
                                <p className="text-lg md:text-2xl text-slate-200 leading-relaxed font-light italic font-tech">
                                    "{selectedInvestor.philosophy}"
                                </p>
                            </div>

                            {/* Strategy Breakdown */}
                            <div className="space-y-4">
                                <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                                    <Target size={14} className="text-emerald-500" /> Strategic Approach
                                </h4>
                                <div className="bg-black/40 p-6 md:p-8 rounded-3xl border border-white/5 text-slate-400 text-sm md:text-base leading-8 font-light">
                                    <p>
                                        <span className="text-white font-bold">{selectedInvestor.name}'s</span> approach employs the <span className="text-emerald-400 font-bold">{selectedInvestor.strategy}</span> model. 
                                        This institutional methodology focuses on capital preservation while aggressively compounding returns through high-conviction positions.
                                        The portfolio construction typically exhibits a concentrated bias towards sectors with significant regulatory moats or underappreciated growth vectors.
                                    </p>
                                </div>
                            </div>

                             {/* Sector Allocation Visualization */}
                             <div className="space-y-4">
                                <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                                    <Layers size={14} className="text-emerald-500" /> Sector Allocation
                                </h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {sectorData.map((sector, i) => (
                                        <div key={i} className="bg-white/5 p-4 rounded-2xl border border-white/5 hover:bg-white/10 transition-colors">
                                            <div className="flex justify-between items-center mb-3">
                                                <span className="text-xs font-bold text-slate-300 truncate pr-2">{sector.name}</span>
                                                <span className="text-xs font-mono text-emerald-500">{sector.value}%</span>
                                            </div>
                                            <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                                                <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${Math.min(100, sector.value)}%` }}></div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                             </div>
                        </div>

                        {/* Right Column: Holdings */}
                        <div className="space-y-6">
                            <div className="flex items-center justify-between mb-2">
                                <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                                    <Briefcase size={14} className="text-emerald-500" /> Top Holdings
                                </h4>
                                <div className="flex items-center gap-2">
                                    <span className="text-[9px] text-slate-500 font-mono uppercase tracking-widest">Perf.</span>
                                    <span className="text-[10px] bg-emerald-500/10 text-emerald-500 px-2 py-1 rounded border border-emerald-500/20 font-bold">
                                        {selectedInvestor.roi}
                                    </span>
                                </div>
                            </div>

                            <div className="space-y-3">
                                {selectedInvestor.portfolio?.slice(0, 5).map((item, i) => (
                                    <div key={i} className="group flex items-center justify-between p-4 md:p-5 bg-slate-900/60 border border-white/5 rounded-2xl hover:border-emerald-500/30 transition-all hover:bg-slate-900 cursor-default">
                                        <div className="flex items-center gap-4">
                                            <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-[10px] font-bold text-slate-400 font-mono border border-white/5 group-hover:text-white group-hover:border-emerald-500/50 transition-colors">
                                                {String(i + 1).padStart(2, '0')}
                                            </div>
                                            <div className="flex flex-col">
                                                <span className="text-sm font-bold text-white group-hover:text-emerald-400 transition-colors truncate max-w-[120px] md:max-w-none">{item.company}</span>
                                                <span className="text-[10px] text-slate-500 font-mono">{item.ticker}</span>
                                            </div>
                                        </div>
                                        <div className="flex flex-col items-end">
                                            <span className="text-sm font-mono font-bold text-white">{item.allocation}</span>
                                            <span className="text-[9px] text-slate-600 uppercase tracking-wide">Weight</span>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className="bg-blue-500/5 border border-blue-500/10 p-6 rounded-3xl mt-4 md:mt-8">
                                <div className="flex gap-4">
                                    <Info className="text-blue-400 shrink-0 mt-0.5" size={18} />
                                    <p className="text-[10px] text-blue-300/80 leading-relaxed font-mono">
                                        DISCLAIMER: Market positions are simulated for educational demonstration. Allocation percentages are derived from public filings (13F/Shareholding patterns) and may vary in real-time.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>,
        document.body
      )}
    </div>
  );
};

export default InvestorSection;
