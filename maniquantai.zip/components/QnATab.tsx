
import React, { useState, useRef, useEffect } from 'react';
import { Send, MessageSquare, Bot, User, Sparkles, AlertCircle } from 'lucide-react';
import { askAIAdvisor } from '../services/geminiService';

interface QnATabProps {
  hasCredits: boolean;
  consumeCredit: () => void;
  openPricing: () => void;
}

interface Message {
  id: number;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

const QnATab: React.FC<QnATabProps> = ({ hasCredits, consumeCredit, openPricing }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      role: 'assistant',
      text: "Welcome to ManiquantAi Advisor. I am ready to provide detailed analysis on trading strategies, financial concepts, or market mechanics. How may I assist you today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || loading) return;

    if (!hasCredits) {
        openPricing();
        return;
    }

    const userMessage: Message = {
      id: Date.now(),
      role: 'user',
      text: input,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);
    consumeCredit();

    try {
      const responseText = await askAIAdvisor(userMessage.text);
      
      const aiMessage: Message = {
        id: Date.now() + 1,
        role: 'assistant',
        text: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
       console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto h-[calc(100vh-8rem)] flex flex-col glass-panel rounded-3xl border border-white/5 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
        {/* Header */}
        <div className="bg-black/40 border-b border-white/5 p-4 md:p-6 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-pink-500/10 border border-pink-500/30 flex items-center justify-center">
                    <MessageSquare size={24} className="text-pink-500" />
                </div>
                <div>
                    <h2 className="text-xl md:text-2xl font-tech font-bold text-white tracking-wide">
                        QUANTUM <span className="text-pink-500">ADVISOR</span>
                    </h2>
                    <p className="text-[10px] text-slate-500 font-mono uppercase tracking-[0.2em]">
                        Deep Learning Financial Assistant
                    </p>
                </div>
            </div>
            {!hasCredits && (
                 <div className="flex items-center gap-2 px-3 py-1 bg-red-500/10 border border-red-500/30 rounded-lg">
                    <AlertCircle size={14} className="text-red-500" />
                    <span className="text-[10px] font-bold text-red-400 uppercase">Credits Depleted</span>
                 </div>
            )}
        </div>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 custom-scrollbar bg-[#05050a]/50">
            {messages.map((msg) => (
                <div 
                    key={msg.id} 
                    className={`flex gap-4 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                    {msg.role === 'assistant' && (
                        <div className="w-8 h-8 rounded-full bg-slate-900 border border-pink-500/30 flex items-center justify-center shrink-0 mt-2">
                            <Bot size={16} className="text-pink-500" />
                        </div>
                    )}
                    
                    <div className={`flex flex-col max-w-[85%] md:max-w-[75%] ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                        <div 
                            className={`p-4 rounded-2xl border text-sm md:text-base leading-relaxed whitespace-pre-line shadow-lg
                            ${msg.role === 'user' 
                                ? 'bg-gradient-to-br from-pink-600 to-purple-800 text-white border-pink-500/30 rounded-tr-none' 
                                : 'bg-slate-900/80 text-slate-200 border-white/10 rounded-tl-none'}`}
                        >
                            {msg.text}
                        </div>
                        <span className="text-[10px] text-slate-600 font-mono mt-1 px-2">{msg.timestamp}</span>
                    </div>

                    {msg.role === 'user' && (
                        <div className="w-8 h-8 rounded-full bg-slate-900 border border-white/10 flex items-center justify-center shrink-0 mt-2">
                            <User size={16} className="text-slate-400" />
                        </div>
                    )}
                </div>
            ))}
            
            {loading && (
                <div className="flex gap-4 justify-start">
                     <div className="w-8 h-8 rounded-full bg-slate-900 border border-pink-500/30 flex items-center justify-center shrink-0">
                        <Sparkles size={16} className="text-pink-500 animate-pulse" />
                    </div>
                    <div className="bg-slate-900/50 p-4 rounded-2xl rounded-tl-none border border-white/5 flex items-center gap-2">
                        <span className="w-2 h-2 bg-pink-500 rounded-full animate-bounce"></span>
                        <span className="w-2 h-2 bg-pink-500 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></span>
                        <span className="w-2 h-2 bg-pink-500 rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></span>
                    </div>
                </div>
            )}
            <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 md:p-6 bg-black/40 border-t border-white/5 shrink-0">
            <form onSubmit={handleSend} className="relative">
                <input 
                    type="text" 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder={hasCredits ? "Ask detailed questions about markets, strategies, or concepts..." : "Please recharge credits to continue..."}
                    disabled={!hasCredits || loading}
                    className="w-full bg-[#0c1321] text-white placeholder:text-slate-600 rounded-xl py-4 pl-6 pr-14 border border-slate-800 focus:border-pink-500 outline-none transition-all font-tech tracking-wide"
                />
                <button 
                    type="submit"
                    disabled={!input.trim() || !hasCredits || loading}
                    className="absolute right-2 top-2 p-2 bg-pink-600 hover:bg-pink-500 text-white rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <Send size={20} />
                </button>
            </form>
            <div className="text-center mt-3">
                 <p className="text-[9px] text-slate-600 font-mono uppercase tracking-widest">
                    ManiquantAi Advisor may produce varied results. Verify all financial data independently.
                 </p>
            </div>
        </div>
    </div>
  );
};

export default QnATab;
