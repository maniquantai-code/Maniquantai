import React, { useEffect, useState } from 'react';
import { fetchMarketNews } from '../services/geminiService';
import { NewsItem } from '../types';
import { MOCK_NEWS } from '../constants';
import { ExternalLink, RefreshCw, Zap } from 'lucide-react';

const NewsSection: React.FC = () => {
    const [news, setNews] = useState<NewsItem[]>([]);
    const [loading, setLoading] = useState(true);

    const loadNews = async () => {
        setLoading(true);
        try {
            const liveNews = await fetchMarketNews();
            if (liveNews && liveNews.length > 0) {
                setNews(liveNews);
            } else {
                setNews(MOCK_NEWS); // Fallback to mocks if API fails or returns empty
            }
        } catch (error) {
            console.error("News load failed:", error);
            setNews(MOCK_NEWS);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadNews();
    }, []);

    return (
        <div className="py-12 px-4 max-w-7xl mx-auto relative">
             <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-tech font-bold text-white border-l-4 border-neon-purple pl-4 flex items-center">
                    <Zap className="text-neon-purple mr-2" size={20} />
                    Live Terminal Intelligence
                </h3>
                <button 
                    onClick={loadNews}
                    disabled={loading}
                    className="p-2 rounded-lg bg-slate-900 border border-slate-700 text-slate-400 hover:text-neon-blue hover:border-neon-blue/50 transition-all disabled:opacity-50"
                    title="Refresh News Feed"
                >
                    <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
                </button>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                 {loading ? (
                     [1, 2, 3].map(i => (
                        <div key={i} className="bg-slate-900/40 p-6 rounded-xl border border-slate-800 animate-pulse h-[200px] flex flex-col">
                            <div className="h-4 w-24 bg-slate-800 rounded mb-4"></div>
                            <div className="h-6 w-full bg-slate-800 rounded mb-2"></div>
                            <div className="h-6 w-3/4 bg-slate-800 rounded mt-auto"></div>
                        </div>
                     ))
                 ) : (
                     news.map((item) => (
                        <div key={item.id} className="bg-slate-900/40 p-6 rounded-xl border border-slate-700 hover:border-neon-blue/30 transition-all group flex flex-col h-full hover:bg-slate-900/60 backdrop-blur-sm">
                            <div className="flex justify-between items-start mb-4">
                                <span className="text-[10px] font-mono text-neon-blue uppercase tracking-widest bg-neon-blue/5 px-2 py-0.5 rounded border border-neon-blue/20">{item.source}</span>
                                <span className="text-[10px] text-slate-500 font-mono">{item.time}</span>
                            </div>
                            <h4 className="text-lg font-bold text-slate-200 mb-4 group-hover:text-white transition-colors flex-grow leading-tight font-tech">
                                {item.title}
                            </h4>
                            <a 
                                href={item.url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="flex items-center text-xs text-slate-400 hover:text-neon-blue transition-all mt-auto font-bold tracking-widest group/link"
                            >
                                EXECUTE DEEP READ 
                                <ExternalLink size={12} className="ml-2 group-hover/link:translate-x-1 group-hover/link:-translate-y-1 transition-transform" />
                            </a>
                        </div>
                     ))
                 )}
             </div>
        </div>
    );
};

export default NewsSection;