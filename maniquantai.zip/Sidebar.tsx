
import React from 'react';
import { 
  Cpu, 
  History, 
  Zap, 
  LogOut, 
  Crown, 
  Globe,
  Users
} from 'lucide-react';
import { UserState, PlanType } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  user: UserState;
  onLogout: () => void;
  onOpenPricing: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, user, onLogout, onOpenPricing }) => {
  const navItems = [
    { id: 'vision', label: 'Vision', icon: Cpu, color: 'text-neon-green' },
    { id: 'simulator', label: 'Sim', icon: History, color: 'text-neon-purple' },
    { id: 'investors', label: 'Titans', icon: Users, color: 'text-yellow-400' },
    { id: 'intelligence', label: 'Intel', icon: Globe, color: 'text-blue-400' },
  ];

  return (
    <>
      {/* Desktop Sidebar */}
      <div className="hidden lg:flex w-64 h-screen bg-[#05050a]/80 backdrop-blur-2xl border-r border-white/5 flex-col z-50 transition-all duration-300">
        <div className="p-6 flex items-center gap-3">
          {/* Logo container mimicking the user's uploaded image */}
          <div className="relative w-10 h-10 flex items-center justify-center">
            <div className="absolute inset-0 bg-emerald-500/20 rounded-full blur-md animate-pulse"></div>
            <div className="relative w-8 h-8 bg-slate-900 border border-emerald-500/30 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(16,185,129,0.3)]">
              <Cpu className="text-emerald-500" size={18} />
            </div>
          </div>
          <h1 className="text-xl font-tech font-bold text-white tracking-tighter">
            Maniquant<span className="text-emerald-500">Ai</span>
          </h1>
        </div>

        <div className="px-4 mb-8">
          <div className="bg-white/5 rounded-2xl p-4 border border-white/5 hover:border-emerald-500/30 transition-all cursor-pointer group" onClick={onOpenPricing}>
            <div className="flex justify-between items-center mb-2">
               <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Neural Credits</span>
               <Zap size={12} className="text-emerald-500 group-hover:animate-pulse" />
            </div>
            <div className="flex items-end gap-2">
              <span className="text-2xl font-mono font-bold text-white">
                {user.plan === PlanType.ELITE ? '∞' : user.credits}
              </span>
              <span className="text-[10px] text-emerald-500 font-bold mb-1">UNITS</span>
            </div>
            <div className="mt-3 h-1 w-full bg-slate-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-emerald-500" 
                style={{ width: user.plan === PlanType.ELITE ? '100%' : `${Math.min(100, (user.credits / 100) * 100)}%` }}
              ></div>
            </div>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-xl transition-all duration-300 relative group
                ${activeTab === item.id 
                  ? 'bg-emerald-500/10 text-white border border-emerald-500/20' 
                  : 'text-slate-500 hover:text-white hover:bg-white/5'
                }`}
            >
              <item.icon size={20} className={activeTab === item.id ? item.color : 'text-slate-500 group-hover:text-white'} />
              <span className="font-tech font-bold tracking-widest text-sm uppercase">{item.label} Engine</span>
              {activeTab === item.id && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-emerald-500 rounded-r-full shadow-[0_0_10px_#10b981]"></div>
              )}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5 space-y-2">
          <button onClick={onOpenPricing} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-500 hover:text-yellow-400 transition-all group">
            <Crown size={20} />
            <span className="font-tech font-bold tracking-widest text-sm uppercase">Upgrade</span>
          </button>
          <button onClick={onLogout} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-slate-500 hover:text-red-500 transition-all group">
            <LogOut size={20} />
            <span className="font-tech font-bold tracking-widest text-sm uppercase">Exit Terminal</span>
          </button>
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-[#05050a]/90 backdrop-blur-xl border-t border-white/10 px-4 py-2 flex justify-around items-center z-[90]">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center gap-1 p-2 transition-all rounded-xl ${activeTab === item.id ? 'text-emerald-500' : 'text-slate-500'}`}
          >
            <item.icon size={20} />
            <span className="text-[10px] font-tech font-bold uppercase tracking-tighter">{item.label}</span>
          </button>
        ))}
        <button 
          onClick={onOpenPricing}
          className="flex flex-col items-center gap-1 p-2 text-yellow-500"
        >
          <Zap size={20} />
          <span className="text-[10px] font-tech font-bold uppercase tracking-tighter">{user.plan === PlanType.ELITE ? '∞' : user.credits}</span>
        </button>
      </div>
    </>
  );
};

export default Sidebar;
