
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Marquee from './components/Marquee';
import ChartAnalyzer from './components/ChartAnalyzer';
import Simulator from './components/Simulator';
import NewsSection from './components/NewsSection';
import InvestorSection from './components/InvestorSection';
import MarketHoldings from './components/MarketHoldings';
import AuthPage from './components/AuthPage';
import TradingBackground from './components/TradingBackground';
import Pricing from './components/Pricing';
import QnATab from './components/QnATab';
import { UserState, PlanType, Investor } from './types';
import { INITIAL_CREDITS, PLANS, MOCK_INVESTORS } from './constants';
import { parseInvestorData, fetchMoreInvestors } from './services/geminiService';
import { supabase } from './services/supabaseClient';
import { X, Search, Bell, Settings, Menu, Cpu, Wallet, LogOut } from 'lucide-react';

const SHEET_ID = '1xtOrxXmwFuMq_YKarHV1De0-ORWS5pi4Q9G5joZCwuU';
const SHEET_URL = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/export?format=csv`;

function App() {
  const [session, setSession] = useState<any>(null);
  const [showPricing, setShowPricing] = useState(false);
  const [pricingMessage, setPricingMessage] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('vision');
  const [investors, setInvestors] = useState<Investor[]>(MOCK_INVESTORS);
  const [investorsLoading, setInvestorsLoading] = useState(true);
  
  const [user, setUser] = useState<UserState>({
    credits: INITIAL_CREDITS,
    plan: PlanType.FREE,
    autoPayEnabled: false,
  });

  // Handle Authentication Session
  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session) fetchUserProfile(session.user.id);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) {
        fetchUserProfile(session.user.id);
      } else {
        setUser({ credits: INITIAL_CREDITS, plan: PlanType.FREE, autoPayEnabled: false });
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchUserProfile = async (userId: string) => {
    try {
        // Try to fetch existing profile
        const { data, error } = await supabase
            .from('profiles')
            .select('plan, credits')
            .eq('id', userId)
            .single();

        if (data) {
            // Profile exists, load state
            setUser(prev => ({
                ...prev,
                plan: (data.plan as PlanType) || PlanType.FREE,
                credits: data.credits !== undefined ? data.credits : INITIAL_CREDITS,
                autoPayEnabled: data.plan !== PlanType.FREE
            }));
        } else {
            // Profile missing (e.g. created during signup without session)
            // Fallback to user_metadata and try to create the row now that we have a session
            const { data: { user } } = await supabase.auth.getUser();
            
            if (user) {
                const meta = user.user_metadata;
                const defaultPlan = meta?.plan || PlanType.FREE;
                const defaultCredits = meta?.credits !== undefined ? meta.credits : INITIAL_CREDITS;
                
                // Set local state immediately for responsiveness
                setUser(prev => ({ 
                    ...prev, 
                    plan: defaultPlan, 
                    credits: defaultCredits, 
                    autoPayEnabled: defaultPlan !== PlanType.FREE 
                }));

                // Lazy Create Profile Row
                const { error: upsertError } = await supabase.from('profiles').upsert({
                     id: user.id,
                     email: user.email,
                     username: meta?.username || user.email?.split('@')[0],
                     plan: defaultPlan,
                     credits: defaultCredits
                });

                if (upsertError) {
                   console.error("Lazy profile creation log:", upsertError);
                }
            }
        }
    } catch (err) {
        console.error("Profile fetch logic error:", err);
    }
  };

  useEffect(() => {
    if (!session) return;
    
    const fetchData = async () => {
      try {
        setInvestorsLoading(true);
        
        // Parallel fetch for speed: Sheet + Web Search
        const [sheetResponse, webInvestors] = await Promise.all([
            fetch(SHEET_URL).catch(() => null),
            fetchMoreInvestors().catch(() => [])
        ]);

        let sheetInvestors: Investor[] = [];
        if (sheetResponse && sheetResponse.ok) {
             const csvText = await sheetResponse.text();
             sheetInvestors = await parseInvestorData(csvText);
        }

        // Combine unique investors from Mock, Sheet, and Web
        const combined = [...MOCK_INVESTORS, ...sheetInvestors, ...webInvestors];
        
        // Deduplicate by name
        const uniqueInvestors = Array.from(new Map(combined.map(item => [item.name, item])).values());
        
        setInvestors(uniqueInvestors);
      } catch (error) {
        console.error("Failed to load investor data", error);
      } finally {
        setInvestorsLoading(false);
      }
    };
    
    fetchData();
  }, [session]);

  const handleOpenPricing = (message?: string) => {
    setPricingMessage(typeof message === 'string' ? message : null);
    setShowPricing(true);
  };

  const consumeCredit = async () => {
    if (user.plan === PlanType.ELITE) return;
    
    const newCredits = Math.max(0, user.credits - 1);
    
    // Optimistic update
    setUser(prev => ({ ...prev, credits: newCredits }));
    
    if (user.credits === 1) {
        setPricingMessage("Credits depleted. Recharge to continue.");
        setTimeout(() => setShowPricing(true), 1500);
    }

    // DB Update
    if (session?.user?.id) {
        await supabase
            .from('profiles')
            .update({ credits: newCredits })
            .eq('id', session.user.id);
    }
  };

  const handleUpgrade = async (newPlan: PlanType) => {
    const planDetails = PLANS[newPlan];
    
    const updatedUser = {
        credits: planDetails.credits,
        plan: newPlan,
        autoPayEnabled: true
    };

    // Optimistic Update
    setUser(prev => ({ ...prev, ...updatedUser }));
    setShowPricing(false);
    setPricingMessage(null);

    // DB Update
    if (session?.user?.id) {
        await supabase
            .from('profiles')
            .update({ 
                plan: newPlan,
                credits: planDetails.credits 
            })
            .eq('id', session.user.id);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setShowPricing(false);
    setPricingMessage(null);
  };

  if (!session) {
    return <AuthPage onLogin={() => {}} />;
  }

  const hasCredits = user.credits > 0 || user.plan === PlanType.ELITE;
  const isLocked = user.plan === PlanType.FREE && user.credits <= 0;

  return (
    <div className="min-h-screen bg-[#020405] text-slate-200 flex flex-col selection:bg-emerald-500/30 selection:text-white overflow-hidden">
      <Marquee />

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        <TradingBackground />

        <Sidebar 
          activeTab={activeTab} 
          setActiveTab={setActiveTab} 
          user={user} 
          onLogout={handleLogout} 
          onOpenPricing={() => handleOpenPricing()} 
        />

        <div className="flex-1 flex flex-col relative z-10 overflow-hidden h-full">
          {/* Main Header mimicking the user's screenshot - HIDDEN ON DESKTOP */}
          <header className="h-16 md:h-16 bg-[#05050a] border-b border-white/5 px-4 md:px-6 flex items-center justify-between shrink-0 lg:hidden">
             <div className="flex items-center gap-4">
                <div className="relative w-9 h-9 flex items-center justify-center">
                  <div className="absolute inset-0 bg-emerald-500/20 rounded-lg blur-[2px]"></div>
                  <div className="relative w-8 h-8 bg-[#0a0a0a] border border-emerald-500/40 rounded-lg flex items-center justify-center shadow-[0_0_10px_rgba(16,185,129,0.3)]">
                    <Cpu size={18} className="text-emerald-500" />
                  </div>
                </div>
                <h1 className="text-xl md:text-2xl font-sans font-extrabold text-white tracking-tight flex items-center">
                  MANIQUANT<span className="text-emerald-400 ml-0.5">Ai</span>
                </h1>
             </div>

             <div className="flex items-center gap-3">
                <button 
                  onClick={() => handleOpenPricing()}
                  className="flex items-center gap-2 px-3 py-1.5 bg-[#0c1321] border border-white/10 rounded-lg hover:border-emerald-500/40 transition-all group"
                >
                  <Wallet size={16} className="text-emerald-500" />
                  <span className="text-sm font-mono font-bold text-white leading-none">
                    {user.plan === PlanType.ELITE ? '∞' : user.credits}
                  </span>
                </button>
                <button 
                  onClick={handleLogout}
                  className="p-2 bg-[#0c1321] border border-white/10 rounded-lg text-slate-400 hover:text-red-400 hover:border-red-400/40 transition-all"
                >
                  <LogOut size={16} />
                </button>
             </div>
          </header>

          <main className="flex-1 overflow-y-auto custom-scrollbar p-4 md:p-6 pb-24 lg:pb-8">
              <div className="max-w-7xl mx-auto space-y-8 md:space-y-12">
                  {activeTab === 'vision' && (
                    <ChartAnalyzer 
                      hasCredits={hasCredits} 
                      consumeCredit={consumeCredit} 
                      openPricing={handleOpenPricing} 
                    />
                  )}

                  {activeTab === 'simulator' && (
                    <Simulator 
                      hasCredits={hasCredits} 
                      consumeCredit={consumeCredit} 
                      openPricing={() => handleOpenPricing()} 
                    />
                  )}

                  {activeTab === 'investors' && (
                    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-8 duration-700">
                      <InvestorSection 
                        investors={investors} 
                        loading={investorsLoading} 
                        isLocked={isLocked} 
                        onUnlock={() => handleOpenPricing()} 
                      />
                      {!isLocked && (
                        <MarketHoldings 
                          investors={investors} 
                          loading={investorsLoading} 
                        />
                      )}
                    </div>
                  )}

                  {activeTab === 'intelligence' && (
                    <div className="space-y-12">
                      <NewsSection />
                    </div>
                  )}

                  {activeTab === 'qna' && (
                    <QnATab 
                      hasCredits={hasCredits} 
                      consumeCredit={consumeCredit} 
                      openPricing={() => handleOpenPricing()} 
                    />
                  )}
              </div>
          </main>
        </div>
      </div>

      {showPricing && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-2 md:p-4">
          <div className="absolute inset-0 bg-black/90 backdrop-blur-lg" onClick={() => setShowPricing(false)}></div>
          <div className="relative z-10 w-full max-w-6xl max-h-[90vh] overflow-y-auto custom-scrollbar bg-[#020405] rounded-[2rem] md:rounded-[3rem] border border-slate-800 shadow-2xl">
            <button 
              onClick={() => setShowPricing(false)}
              className="absolute top-4 right-4 md:top-8 md:right-8 text-slate-500 hover:text-white z-50 p-2 md:p-3 bg-black/50 rounded-full"
            >
              <X size={20} />
            </button>
            <div className="p-6 md:p-12">
              <Pricing currentPlan={user.plan} onUpgrade={handleUpgrade} message={pricingMessage} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
